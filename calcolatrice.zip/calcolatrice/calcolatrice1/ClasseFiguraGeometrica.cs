﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace primo_form
{
    public class ClasseFiguraGeometrica
    {
        //ATTRIBUTI (pk li ereditano quelli sotto di lei)
        protected double area;
        protected double perimetro;

        //METODI
        public ClasseFiguraGeometrica()
        {
            area = 0;
            perimetro = 0;
        }

        void setArea(double val) //si usa double ma possiamo usare anche float
        {
            area = val;
        }
        double getArea()
        {
            return area;
        }
        double calcolaArea() //polimorfismo
        {
            return area;
        }
        void setPerimetro(double val)
        {
            perimetro = val;
        }
        double getPerimetro()
        {
            return perimetro;
        }
        double calcolaPerimetro() //polimorfismo
        {
            return perimetro;
        }

        ~ClasseFiguraGeometrica() { }
    }

        //poligono
        public class Poligono : ClasseFiguraGeometrica
        {
            //ATTRIBUTI
            protected double numLati;
            public Poligono(double n) //costruttore
            {
                numLati = n;
            }
            ~Poligono() { }
        };
        public class Rettangolo : Poligono
        {
            //ATTRIBUTI
            protected double baseRettangolo;
            protected double altezza;

            //METODI
            public Rettangolo() : base(4) //costruttore 1
            {
                baseRettangolo = 0;
                altezza = 0;
            }
            public Rettangolo(double b, double a) : base(4) //costruttore 2
            {
                baseRettangolo = b;
                altezza = a;
            }

            public void setAltezza(double v)
            {
                altezza = v;
            }
            public double getAltezza()
            {
                return altezza;
            }
            public void setBase(double b)
            {
                baseRettangolo = b;
            }
            public double getBase()
            {
                return baseRettangolo;
            }
            public double calcolaAreaa()
            {
                area = baseRettangolo * altezza;
                return area;
            }
            public double calcolaPerimetroo()
            {
                perimetro = baseRettangolo + altezza + baseRettangolo + altezza;
                return perimetro;
            }

            ~Rettangolo() { }
        }
        public class Quadrato : Rettangolo
        {
            protected double lato;

            public Quadrato(double l) //costruttore 2
            {
                 lato = l;
            }

            public double calcolaArea()
            {
                area = lato * lato;
                return area;
            }
            public double calcolaPerimetro()
            {
                perimetro = lato * 4;
                return perimetro;
            }

            ~Quadrato() { }
        }
        public class Triangolo : Poligono
        {
        public double lato1;
        public double lato2;
        public double baseTriangolo;
        public double altezza;
        public string tipo;

        public Triangolo () : base(3)
        {
            lato1 = 0;
            lato2 = 0;
            baseTriangolo = 0;
            altezza = 0;
            tipo = "";
        }

        public Triangolo(double l1, double l2, double b, double a) : base(3) //scaleno
        {
            lato1 = l1;
            lato2 = l2;
            baseTriangolo = b;
            altezza = a;
            tipo = "Scaleno";
        }
        public Triangolo(double l1, double l2, double a) : base(3) //isoscele
        {
            lato1 = l1;
            lato2 = l2;
            baseTriangolo = l2;
            altezza = a;
            tipo = "Isoscele";
        }
        public Triangolo(double l1, double a) : base(3) //rettangolo
        {
            lato1 = l1;
            lato2 = l1;
            baseTriangolo = l1;
            altezza = a;
            tipo = "Rettangolo";
        }

        void setLato1(double l1)
        {
            lato1 = l1;
        }
        double getLato1()
        {
            return lato1;
        }
        void setLato2(double l2)
        {
            lato2 = l2;
        }
        double getLato2()
        {
            return lato2;
        }
        void setAltezza(double v)
        {
            altezza = v;
        }
        double getAltezza()
        {
            return altezza;
        }
        void setBase(double b)
        {
            baseTriangolo = b;
        }
        double getBase()
        {
            return baseTriangolo;
        }

        public double calcolaArea()
        {
            area = (baseTriangolo * altezza) / 2;
            return area;
        }
        public double calcolaPerimetro()
        {
            perimetro = lato1 + lato2 + baseTriangolo;
            return perimetro;
        }

        ~Triangolo() { }
        }
        
        //ellisse
        public class Ellisse : ClasseFiguraGeometrica
    {
        protected double raggioMaggiore;
        protected double raggioMinore;

        public Ellisse(double rMag, double rMin)
        {
            raggioMaggiore = rMag;
            raggioMinore = rMin;
        }
        public double CalcolaArea()
        {
            area = Math.PI * raggioMaggiore * raggioMinore;
            return area;
        }
    };
        public class Cerchio : Ellisse
        {
            //ATTRIBUTI
            protected double raggio;

        public Cerchio(double r) : base(r, r)
        {
            raggio = r;
        }
        public double CalcolaArea()
        {
            area = Math.PI * Math.Pow(raggio, 2);
            return area;
        }
        public double CalcolaPerimetro()
        {
            perimetro = 2 * Math.PI * raggio;
            return perimetro;
        }
        }
}
//altro form dove metto il codice dell'interfaccia (quindi groupbox con rdb perimetro quadrato e cosi via per le figure, poi un bottone calcola, azzera, chiudi e ritorna) e collegarlo a questo codice qui.