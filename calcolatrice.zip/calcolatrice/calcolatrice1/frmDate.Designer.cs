﻿namespace primo_form
{
    partial class frmDate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.grb1 = new System.Windows.Forms.GroupBox();
            this.lb3 = new System.Windows.Forms.ListBox();
            this.lb2 = new System.Windows.Forms.ListBox();
            this.lb1 = new System.Windows.Forms.ListBox();
            this.rdbOggi = new System.Windows.Forms.RadioButton();
            this.rdbConDate = new System.Windows.Forms.RadioButton();
            this.rdbAddAnni = new System.Windows.Forms.RadioButton();
            this.rdbAddGiorni = new System.Windows.Forms.RadioButton();
            this.rdbAddMesi = new System.Windows.Forms.RadioButton();
            this.rdbData2 = new System.Windows.Forms.RadioButton();
            this.rdbData1 = new System.Windows.Forms.RadioButton();
            this.dtp1 = new System.Windows.Forms.DateTimePicker();
            this.dtp2 = new System.Windows.Forms.DateTimePicker();
            this.btnRisultato = new System.Windows.Forms.Button();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.lblAZZERA = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip5 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip6 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip7 = new System.Windows.Forms.ToolTip(this.components);
            this.grb1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.BackColor = System.Drawing.Color.LavenderBlush;
            this.txt1.Location = new System.Drawing.Point(26, 278);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(237, 52);
            this.txt1.TabIndex = 0;
            // 
            // grb1
            // 
            this.grb1.BackColor = System.Drawing.Color.Pink;
            this.grb1.Controls.Add(this.lb3);
            this.grb1.Controls.Add(this.lb2);
            this.grb1.Controls.Add(this.lb1);
            this.grb1.Controls.Add(this.rdbOggi);
            this.grb1.Controls.Add(this.rdbConDate);
            this.grb1.Controls.Add(this.rdbAddAnni);
            this.grb1.Controls.Add(this.rdbAddGiorni);
            this.grb1.Controls.Add(this.rdbAddMesi);
            this.grb1.Controls.Add(this.rdbData2);
            this.grb1.Controls.Add(this.rdbData1);
            this.grb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grb1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.grb1.Location = new System.Drawing.Point(308, 32);
            this.grb1.Name = "grb1";
            this.grb1.Size = new System.Drawing.Size(285, 298);
            this.grb1.TabIndex = 1;
            this.grb1.TabStop = false;
            this.grb1.Text = "Operazioni sulle date";
            // 
            // lb3
            // 
            this.lb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb3.FormattingEnabled = true;
            this.lb3.Items.AddRange(new object[] {
            "-10",
            "-9",
            "-8",
            "-7",
            "-6",
            "-5",
            "-4",
            "-3",
            "-2",
            "-1",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.lb3.Location = new System.Drawing.Point(171, 191);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(91, 17);
            this.lb3.TabIndex = 9;
            // 
            // lb2
            // 
            this.lb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb2.FormattingEnabled = true;
            this.lb2.Items.AddRange(new object[] {
            "-10",
            "-9",
            "-8",
            "-7",
            "-6",
            "-5",
            "-4",
            "-3",
            "-2",
            "-1",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.lb2.Location = new System.Drawing.Point(171, 151);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(91, 17);
            this.lb2.TabIndex = 8;
            // 
            // lb1
            // 
            this.lb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb1.FormattingEnabled = true;
            this.lb1.Items.AddRange(new object[] {
            "-10",
            "-9",
            "-8",
            "-7",
            "-6",
            "-5",
            "-4",
            "-3",
            "-2",
            "-1",
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.lb1.Location = new System.Drawing.Point(171, 112);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(91, 17);
            this.lb1.TabIndex = 7;
            // 
            // rdbOggi
            // 
            this.rdbOggi.AutoSize = true;
            this.rdbOggi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbOggi.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbOggi.Location = new System.Drawing.Point(28, 271);
            this.rdbOggi.Name = "rdbOggi";
            this.rdbOggi.Size = new System.Drawing.Size(47, 17);
            this.rdbOggi.TabIndex = 6;
            this.rdbOggi.TabStop = true;
            this.rdbOggi.Text = "Oggi";
            this.toolTip7.SetToolTip(this.rdbOggi, "Restituisce la data di oggi");
            this.rdbOggi.UseVisualStyleBackColor = true;
            this.rdbOggi.CheckedChanged += new System.EventHandler(this.rdbOggi_CheckedChanged);
            // 
            // rdbConDate
            // 
            this.rdbConDate.AutoSize = true;
            this.rdbConDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbConDate.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbConDate.Location = new System.Drawing.Point(28, 236);
            this.rdbConDate.Name = "rdbConDate";
            this.rdbConDate.Size = new System.Drawing.Size(97, 17);
            this.rdbConDate.TabIndex = 5;
            this.rdbConDate.TabStop = true;
            this.rdbConDate.Text = "Confronta Date";
            this.toolTip6.SetToolTip(this.rdbConDate, "confronta le due date inserite");
            this.rdbConDate.UseVisualStyleBackColor = true;
            // 
            // rdbAddAnni
            // 
            this.rdbAddAnni.AutoSize = true;
            this.rdbAddAnni.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbAddAnni.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbAddAnni.Location = new System.Drawing.Point(28, 191);
            this.rdbAddAnni.Name = "rdbAddAnni";
            this.rdbAddAnni.Size = new System.Drawing.Size(90, 17);
            this.rdbAddAnni.TabIndex = 4;
            this.rdbAddAnni.TabStop = true;
            this.rdbAddAnni.Text = "Aggiungi Anni";
            this.toolTip5.SetToolTip(this.rdbAddAnni, "Aggiunge gli anni indicati a lato, alla data inserita");
            this.rdbAddAnni.UseVisualStyleBackColor = true;
            this.rdbAddAnni.CheckedChanged += new System.EventHandler(this.rdbAddAnni_CheckedChanged);
            // 
            // rdbAddGiorni
            // 
            this.rdbAddGiorni.AutoSize = true;
            this.rdbAddGiorni.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbAddGiorni.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbAddGiorni.Location = new System.Drawing.Point(27, 151);
            this.rdbAddGiorni.Name = "rdbAddGiorni";
            this.rdbAddGiorni.Size = new System.Drawing.Size(96, 17);
            this.rdbAddGiorni.TabIndex = 3;
            this.rdbAddGiorni.TabStop = true;
            this.rdbAddGiorni.Text = "Aggiungi Giorni";
            this.toolTip4.SetToolTip(this.rdbAddGiorni, "Aggiunge i giorni indicati a lato, alla data inserita");
            this.rdbAddGiorni.UseVisualStyleBackColor = true;
            this.rdbAddGiorni.CheckedChanged += new System.EventHandler(this.rdbAddGiorni_CheckedChanged);
            // 
            // rdbAddMesi
            // 
            this.rdbAddMesi.AutoSize = true;
            this.rdbAddMesi.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbAddMesi.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbAddMesi.Location = new System.Drawing.Point(27, 112);
            this.rdbAddMesi.Name = "rdbAddMesi";
            this.rdbAddMesi.Size = new System.Drawing.Size(91, 17);
            this.rdbAddMesi.TabIndex = 2;
            this.rdbAddMesi.TabStop = true;
            this.rdbAddMesi.Text = "Aggiungi Mesi";
            this.toolTip3.SetToolTip(this.rdbAddMesi, "Aggiunge i mesi indicati a lato, alla data inserita");
            this.rdbAddMesi.UseVisualStyleBackColor = true;
            this.rdbAddMesi.CheckedChanged += new System.EventHandler(this.rdbAddMesi_CheckedChanged);
            // 
            // rdbData2
            // 
            this.rdbData2.AutoSize = true;
            this.rdbData2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbData2.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbData2.Location = new System.Drawing.Point(27, 64);
            this.rdbData2.Name = "rdbData2";
            this.rdbData2.Size = new System.Drawing.Size(127, 17);
            this.rdbData2.TabIndex = 1;
            this.rdbData2.TabStop = true;
            this.rdbData2.Text = "Visualizza Data (EXT)";
            this.toolTip2.SetToolTip(this.rdbData2, "Visuliazza la data inserita in modo esteso");
            this.rdbData2.UseVisualStyleBackColor = true;
            this.rdbData2.CheckedChanged += new System.EventHandler(this.rdbData2_CheckedChanged);
            // 
            // rdbData1
            // 
            this.rdbData1.AutoSize = true;
            this.rdbData1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbData1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.rdbData1.Location = new System.Drawing.Point(28, 27);
            this.rdbData1.Name = "rdbData1";
            this.rdbData1.Size = new System.Drawing.Size(97, 17);
            this.rdbData1.TabIndex = 0;
            this.rdbData1.TabStop = true;
            this.rdbData1.Text = "Visualizza Data";
            this.toolTip1.SetToolTip(this.rdbData1, "Visuliazza la data inserita");
            this.rdbData1.UseVisualStyleBackColor = true;
            this.rdbData1.CheckedChanged += new System.EventHandler(this.rdbData1_CheckedChanged);
            // 
            // dtp1
            // 
            this.dtp1.CalendarForeColor = System.Drawing.Color.LightPink;
            this.dtp1.CalendarMonthBackground = System.Drawing.Color.Pink;
            this.dtp1.CalendarTitleBackColor = System.Drawing.Color.LightPink;
            this.dtp1.CalendarTitleForeColor = System.Drawing.Color.PaleVioletRed;
            this.dtp1.CalendarTrailingForeColor = System.Drawing.Color.PaleVioletRed;
            this.dtp1.Location = new System.Drawing.Point(46, 77);
            this.dtp1.Name = "dtp1";
            this.dtp1.Size = new System.Drawing.Size(200, 20);
            this.dtp1.TabIndex = 2;
            // 
            // dtp2
            // 
            this.dtp2.CalendarForeColor = System.Drawing.Color.LightPink;
            this.dtp2.CalendarMonthBackground = System.Drawing.Color.Pink;
            this.dtp2.CalendarTitleBackColor = System.Drawing.Color.LightPink;
            this.dtp2.CalendarTitleForeColor = System.Drawing.Color.PaleVioletRed;
            this.dtp2.CalendarTrailingForeColor = System.Drawing.Color.PaleVioletRed;
            this.dtp2.Location = new System.Drawing.Point(46, 144);
            this.dtp2.Name = "dtp2";
            this.dtp2.Size = new System.Drawing.Size(200, 20);
            this.dtp2.TabIndex = 3;
            // 
            // btnRisultato
            // 
            this.btnRisultato.BackColor = System.Drawing.Color.Pink;
            this.btnRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRisultato.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnRisultato.Location = new System.Drawing.Point(308, 347);
            this.btnRisultato.Name = "btnRisultato";
            this.btnRisultato.Size = new System.Drawing.Size(113, 45);
            this.btnRisultato.TabIndex = 4;
            this.btnRisultato.Text = "Calcola";
            this.btnRisultato.UseVisualStyleBackColor = false;
            this.btnRisultato.Click += new System.EventHandler(this.btnRisultato_Click);
            // 
            // btnChiudi
            // 
            this.btnChiudi.BackColor = System.Drawing.Color.Pink;
            this.btnChiudi.Font = new System.Drawing.Font("Papyrus", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiudi.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnChiudi.Location = new System.Drawing.Point(427, 347);
            this.btnChiudi.Name = "btnChiudi";
            this.btnChiudi.Size = new System.Drawing.Size(166, 45);
            this.btnChiudi.TabIndex = 27;
            this.btnChiudi.Text = "<--- CHIUDI E RITORNA";
            this.btnChiudi.UseVisualStyleBackColor = false;
            this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAzzera.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAzzera.Location = new System.Drawing.Point(46, 347);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(200, 45);
            this.btnAzzera.TabIndex = 37;
            this.btnAzzera.Text = "AZZERA";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // lblAZZERA
            // 
            this.lblAZZERA.AutoSize = true;
            this.lblAZZERA.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAZZERA.Location = new System.Drawing.Point(97, 335);
            this.lblAZZERA.Name = "lblAZZERA";
            this.lblAZZERA.Size = new System.Drawing.Size(94, 9);
            this.lblAZZERA.TabIndex = 38;
            this.lblAZZERA.Text = "CLICCARE 2 VOLTE";
            // 
            // frmDate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(624, 446);
            this.Controls.Add(this.lblAZZERA);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.btnChiudi);
            this.Controls.Add(this.btnRisultato);
            this.Controls.Add(this.dtp2);
            this.Controls.Add(this.dtp1);
            this.Controls.Add(this.grb1);
            this.Controls.Add(this.txt1);
            this.Name = "frmDate";
            this.Text = "frmDate";
            this.grb1.ResumeLayout(false);
            this.grb1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.GroupBox grb1;
        private System.Windows.Forms.RadioButton rdbOggi;
        private System.Windows.Forms.RadioButton rdbConDate;
        private System.Windows.Forms.RadioButton rdbAddAnni;
        private System.Windows.Forms.RadioButton rdbAddGiorni;
        private System.Windows.Forms.RadioButton rdbAddMesi;
        private System.Windows.Forms.RadioButton rdbData2;
        private System.Windows.Forms.RadioButton rdbData1;
        private System.Windows.Forms.DateTimePicker dtp1;
        private System.Windows.Forms.DateTimePicker dtp2;
        private System.Windows.Forms.Button btnRisultato;
        private System.Windows.Forms.ListBox lb3;
        private System.Windows.Forms.ListBox lb2;
        private System.Windows.Forms.ListBox lb1;
        private System.Windows.Forms.Button btnChiudi;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.Label lblAZZERA;
        private System.Windows.Forms.ToolTip toolTip7;
        private System.Windows.Forms.ToolTip toolTip6;
        private System.Windows.Forms.ToolTip toolTip5;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}