﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace primo_form
{
    public partial class frmDate : Form
    {
        public frmDate()
        {
            InitializeComponent();
            //parto con i RadioButton a false
            rdbData1.Checked = false;
            rdbData2.Checked = false;
            rdbAddGiorni.Checked = false;
            rdbAddMesi.Checked = false;
            rdbAddAnni.Checked = false;
            rdbConDate.Checked = false;
            rdbOggi.Checked = false;
            dtp2.Enabled = false;
            dtp2.Visible = false;
            lb1.Visible = false;
            lb1.Enabled = false;
            lb2.Visible = false;
            lb2.Enabled = false;
            lb3.Visible= false;
            lb3.Enabled = false;
        }

        //dichiarazioni
        bool addGiorni = false;
        bool addMesi = false;   
        bool addAnni = false;
        bool conDate = false;

        //bottone per ritornare alla pagina iniziale
        private void btnChiudi_Click(object sender, EventArgs e)
        {
            Close();
        }

        //bottone azzera e risultato
        private void btnAzzera_Click(object sender, EventArgs e)
        {
            //reimpostazione dei booleani
            addMesi = false;
            addGiorni = false;
            addAnni = false;

            //azzeramento delle TextBox
            txt1.Text = "";

            //ripristino della visibilità dei controlli
            txt1.Visible = true;
            dtp2.Visible = false;
            lb1.Visible = false;
            lb2.Visible = false;
            lb3.Visible = false;

            //deselezione dei RadioButton
            rdbData1.Checked = false;
            rdbData2.Checked = false;
            rdbAddGiorni.Checked = false;
            rdbAddMesi.Checked = false;
            rdbAddAnni.Checked = false;
            rdbConDate.Checked = false;
            rdbOggi.Checked = false;

            //focalizzare la prima TextBox
            dtp1.Focus();
        }
        private void btnRisultato_Click(object sender, EventArgs e)
        {
            //rdb aggiungi mesi, giorni e anni
            if (rdbAddMesi.Checked)
            {
                addMesi = true; 
                int mesi = 0;
                string bau = "";
                DateTime dataRisultante;
                bau = lb3.Text;
                mesi = Convert.ToInt32(bau);
                dataRisultante = dtp1.Value.AddMonths(mesi);
                txt1.Text = dataRisultante.ToString("d");
            }
            if (rdbAddGiorni.Checked)
            {
                addGiorni = true;
                int giorni = 0;
                DateTime dataRisultante;
                lb2.Visible = true;
                giorni = Convert.ToInt32(lb2.Text);
                dataRisultante = dtp1.Value.AddDays(giorni);
                txt1.Text = dataRisultante.ToString("d");
            }
            if (rdbAddAnni.Checked)
            {
                addAnni = true;
                int anni = 0;
                DateTime dataRisultante;
                lb3.Visible = true;
                anni = Convert.ToInt32(lb3.Text);
                dataRisultante = dtp1.Value.AddYears(anni);
                txt1.Text = dataRisultante.ToString("d");
            }
            //rdb confronta date (confronta due date e ottiene la differenza)
            if (rdbConDate.Checked)
            {
                dtp2.Enabled = true;
                dtp2.Visible = true;
                int diff = DateTime.Compare(dtp1.Value, dtp2.Value); //modo 1 (-1)
                TimeSpan span = dtp2.Value - dtp1.Value; //modo 2 (10 giorni)
                txt1.Text = "le date differiscono di " + span.Days.ToString() + " giorni";
            }
        }

        //gestione dei radio button
        private void rdbData1_CheckedChanged(object sender, EventArgs e)
        {
            lb1.Visible = false;
            lb2.Visible = false;
            lb3.Visible = false;
            btnRisultato.Visible = false;
            dtp2.Enabled = false;
            dtp2.Visible = false;
            txt1.Text = dtp1.Value.ToString("d");
        }
        private void rdbData2_CheckedChanged(object sender, EventArgs e)
        {
            lb1.Visible = false;
            lb2.Visible = false;
            lb3.Visible = false;
            btnRisultato.Visible = false;
            dtp2.Enabled = false;
            dtp2.Visible = false;
            txt1.Text = dtp1.Value.ToString("D");
        }
        private void rdbOggi_CheckedChanged(object sender, EventArgs e)
        {
            lb1.Visible = false;
            lb2.Visible = false;
            lb3.Visible = false;
            btnRisultato.Visible = false;
            dtp2.Enabled = false;
            dtp2.Visible = false;
            txt1.Text = "oggi e' il " + DateTime.Today.ToString("d");
        }
        private void rdbAddMesi_CheckedChanged(object sender, EventArgs e)
        {
            lb1.Enabled = true;   
            lb1.Visible = true;
            btnRisultato.Visible = true;
            dtp2.Enabled = true;
            dtp2.Visible = true;
        }
        private void rdbAddGiorni_CheckedChanged(object sender, EventArgs e)
        {
            lb2.Enabled = true;
            lb2.Visible = true;
            btnRisultato.Visible = true;
            dtp2.Enabled = true;
            dtp2.Visible = true;
        }
        private void rdbAddAnni_CheckedChanged(object sender, EventArgs e)
        {
            lb3.Enabled = true;
            lb3.Visible = true;
            btnRisultato.Visible = true;
            dtp2.Enabled = true;
            dtp2.Visible = true;
        }
    }
}
