﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using primo_form; //per collegarlo alla "libreria" ClasseFiguraGeometrica.cs

namespace primo_form
{
    public partial class FormFigure3 : Form
    {
        public FormFigure3()
        {
            InitializeComponent();

            //parto con tutti i RadioButton a false
            rdbQuadAr.Checked = false;
            rdbQuadPer.Checked = false;
            rdbRettAr.Checked = false;
            rdbRettPer.Checked = false;
            rdbTriAr.Checked = false;
            rdbTriPer.Checked = false;
            rdbCercAr.Checked = false;
            rdbCercPer.Checked = false;
        }

        //dichiarazioni
        bool quadA = false;
        bool quadP = false;
        bool rettA = false;
        bool rettP = false;
        bool triA = false;
        bool triP = false;
        bool cercA = false;
        bool cercP = false;

        //bottone per azzerare
        private void btnAzzera_Click(object sender, EventArgs e)
        {
            //azzeramento delle TextBox
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
            txtRisultato.Text = "";

            //reimpostazione delle etichette e risultati
            lbl1.Text = "Valore A";
            lbl2.Text = "Valore B";
            lbl3.Text = "Valore C";
            lblOperazione.Text = "";

            //ripristino della visibilità dei controlli
            txt1.Visible = true;
            txt2.Visible = true;
            txt3.Visible = true;
            lbl1.Visible = true;
            lbl2.Visible = true;
            lbl3.Visible = true;
            lblOperazione.Visible = true;

            //deselezione dei RadioButton
            rdbQuadAr.Checked = false;
            rdbQuadPer.Checked = false;
            rdbRettAr.Checked = false;
            rdbRettPer.Checked = false;
            rdbTriAr.Checked = false;
            rdbTriPer.Checked = false;
            rdbCercAr.Checked = false;
            rdbCercPer.Checked = false;

            //reimpostazione dei booleani
            quadA = false;
            quadP = false;
            rettA = false;
            rettP = false;
            triA = false;
            triP = false;
            cercA = false;
            cercP = false;

            //focalizzare la prima TextBox
            txt1.Focus();
        }

        //radio button poligoni e ellisse
        //POLIGONI
        private void rdbQuadAr_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Text = "Inserisci il lato";
            txt1.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            lbl2.Visible = true;
            lbl2.Visible = false;
            txt2.Visible = false;
            quadA = true;
        }
        private void rdbQuadPer_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Text = "Inserisci il lato";
            txt1.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            lbl2.Visible = true;
            lbl2.Visible = false;
            txt2.Visible = false;
            quadP = true;
        }
        private void rdbRettAr_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci il lato 1";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il lato 2";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            rettA = true;
        }
        private void rdbRettPer_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci il lato 1";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il lato 2";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            rettP = true;
        }
        private void rdbTriAr_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci il lato 1";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il lato 2";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            triA = true;
        }
        private void rdbTriPer_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci il lato 1";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il lato 2";
            txt2.Visible = true;
            lbl3.Visible = true;
            lbl3.Text = "Inserisci il lato 3";
            txt3.Visible = true;
            triP = true;
        }
        //ELLISSE
        private void rdbCercAr_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Text = "Inserisci il raggio";
            txt1.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            lbl2.Visible = true;
            lbl2.Visible = false;
            txt2.Visible = false;
            cercA = true;
        }
        private void rdbCercPer_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Text = "Inserisci il raggio";
            txt1.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            lbl2.Visible = true;
            lbl2.Visible = false;
            txt2.Visible = false;
            cercP = true;
        }

        //bottone risultato e ritorna alla pagina iniziale
        private void btnRisultato_Click(object sender, EventArgs e)
        {
            if (txt1.Text != "" || txt2.Text != "" || txt3.Text != "")
            {
                //quadrato
                if (quadA)
                {
                    double lato = Convert.ToDouble(txt1.Text); // legge il valore inserito
                    Quadrato q = new Quadrato(lato); // crea un oggetto Quadrato
                    double area = q.calcolaArea(); // calcola l'area
                    txtRisultato.Text = "Area: " + area.ToString(); // mostra il risultato
                }
                if (quadP)
                {
                    double lato = Convert.ToDouble(txt1.Text);
                    Quadrato q = new Quadrato(lato);
                    double perimetro = q.calcolaPerimetro();
                    txtRisultato.Text = "Perimetro: " + perimetro.ToString();
                }
                //rettangolo
                if (rettA)
                {
                    double baseRett = Convert.ToDouble(txt1.Text);
                    double altezzaRett = Convert.ToDouble(txt2.Text);
                    Rettangolo r = new Rettangolo(baseRett, altezzaRett);
                    double area = r.calcolaAreaa();
                    txtRisultato.Text = "Area: " + area;
                }
                if (rettP)
                {
                    double baseRett = Convert.ToDouble(txt1.Text);
                    double altezzaRett = Convert.ToDouble(txt2.Text);
                    Rettangolo r = new Rettangolo(baseRett, altezzaRett);
                    double perimetro = r.calcolaPerimetroo();
                    txtRisultato.Text = "Perimetro: " + perimetro;
                }
                //triangolo
                if(triA)
                {
                    double baseTri = Convert.ToDouble(txt1.Text);
                    double altezzaTri = Convert.ToDouble(txt2.Text);
                    Triangolo t = new Triangolo(0, 0, baseTri, altezzaTri);
                    double area = t.calcolaArea();
                    txtRisultato.Text = "Area: " + area;
                }
                if (triP)
                {
                    double lato1 = Convert.ToDouble(txt1.Text);
                    double lato2 = Convert.ToDouble(txt2.Text);
                    double baseTri = Convert.ToDouble(txt3.Text);
                    Triangolo t = new Triangolo(lato1, lato2, baseTri, 0);
                    double perimetro = t.calcolaPerimetro();
                    txtRisultato.Text = "Perimetro: " + perimetro;
                }
                //cerchio
                if(cercA)
                {
                    double raggio = Convert.ToDouble(txt1.Text);
                    Cerchio c = new Cerchio(raggio);
                    double area = c.CalcolaArea();
                    txtRisultato.Text = "Area: " + area;
                }
                if (cercP)
                {
                    double circonferenza = Convert.ToDouble(txt1.Text);
                    Cerchio c = new Cerchio(circonferenza);
                    double perimetro = c.CalcolaPerimetro();
                    txtRisultato.Text = "Circonferenza: " + perimetro;
                }
            }
        }
        private void btnChiudi_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
