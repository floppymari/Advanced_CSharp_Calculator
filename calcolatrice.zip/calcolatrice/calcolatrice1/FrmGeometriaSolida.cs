﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace primo_form
{
    public partial class FrmGeometriaSolida : Form
    {
        public FrmGeometriaSolida()
        {
            InitializeComponent();
            
            //parto con tutti i RadioButton a false
            rdbCuboVolume.Checked = false;
            rdbCuboSuperficie.Checked = false;
            rdbCilindroVolume.Checked = false;
            rdbCilindroSuperficie.Checked = false;
            rdbParallelepipedoVolume.Checked = false;
            rdbParallelepipedoSuperficie.Checked = false;
            rdbSferaVolume.Checked = false;
            rdbSferaSuperficie.Checked = false;
        }

        //dichiarazioni
        double primoNumero = 0;
        double secondoNumero = 0;
        double terzoNumero = 0;
        double totale = 0;

        bool cuboV = false;
        bool parallelepipedoV = false;
        bool cilindroV = false;
        bool cuboS = false;
        bool parallelepipedoS = false;
        bool cilindroS = false;
        bool sferaV = false;
        bool sferaS = false;

        //bottone per azzerare
        private void btnAzzera_Click(object sender, EventArgs e)
        {
            //azzeramento delle variabili numeriche
            primoNumero = 0;
            secondoNumero = 0;
            terzoNumero = 0;
            totale = 0;

            //azzeramento delle TextBox
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
            txtRisultato.Text = "";

            //reimpostazione delle etichette e risultati
            lbl1.Text = "Valore A";
            lbl2.Text = "Valore B";
            lbl3.Text = "Valore C";
            lblOperazione.Text = "";

            //ripristino della visibilità dei controlli
            txt1.Visible = true;
            txt2.Visible = true;
            txt3.Visible = true;
            lbl1.Visible = true;
            lbl2.Visible = true;
            lbl3.Visible = true;
            lblOperazione.Visible = true;

            //deselezione dei RadioButton
            rdbCuboVolume.Checked = false;
            rdbCuboSuperficie.Checked = false;
            rdbCilindroVolume.Checked = false;
            rdbCilindroSuperficie.Checked = false;
            rdbParallelepipedoVolume.Checked = false;
            rdbParallelepipedoSuperficie.Checked = false;
            rdbSferaVolume.Checked = false;
            rdbSferaSuperficie.Checked = false;

            //reimpostazione dei booleani
            cuboV = false;
            parallelepipedoV = false;
            cilindroV = false;
            sferaV = false;
            cuboS = false;
            parallelepipedoS = false;
            cilindroS = false;
            sferaS = false;

            //focalizzare la prima TextBox
            txt1.Focus();
        }

        //radio button cubo, cilindro, parallelepipedo, sfera
        private void rdbCuboVolume_CheckedChanged(object sender, EventArgs e)
        {   
            lbl1.Text = "Inserisci il lato";
            txt1.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            lbl2.Visible = true;
            lbl2.Visible = false;
            txt2.Visible = false;
            cuboV = true; 
        }
        private void rdbCuboSuperficie_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Text = "Inserisci il lato";
            txt1.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            lbl2.Visible = true;
            lbl2.Visible = false;
            txt2.Visible = false;
            cuboS = true;
        }
        private void rdbCilindroVolume_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci l'altezza";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il raggio";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            cilindroV = true;
        }
        private void rdbCilindroSuperficie_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci l'altezza";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il raggio";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            cilindroS = true;
        }
        private void rdbParallelepipedoVolume_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci il lato 1";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il lato 2";
            txt2.Visible = true;
            lbl3.Visible = true;
            lbl3.Text = "Inserisci l'altezza";
            txt3.Visible = true;
            parallelepipedoV = true;
        }
        private void rdbParallelepipedoSuperficie_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci il lato 1";
            txt1.Visible = true;
            lbl2.Text = "Inserisci il lato 2";
            txt2.Visible = true;
            lbl3.Visible = true;
            lbl3.Text = "Inserisci l'altezza";
            txt3.Visible = true;
            parallelepipedoS = true;
        }
        private void rdbSferaVolume_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci l'altezza";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il raggio";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            sferaV = true;
        }
        private void rdbSferaSuperficie_CheckedChanged(object sender, EventArgs e)
        {
            lbl1.Visible = true;
            lbl1.Text = "Inserisci l'altezza";
            txt1.Visible = true;
            lbl2.Visible = true;
            lbl2.Text = "Inserisci il raggio";
            txt2.Visible = true;
            lbl3.Visible = false;
            txt3.Visible = false;
            sferaS = true;
        }


        //bottone risultato e ritorna alla pagina iniziale
        private void btnRisultato_Click(object sender, EventArgs e)
        {
            if (txt1.Text != "" || txt2.Text != "" || txt3.Text != "")
            {
                //CUBO 
                if (cuboV)
                {
                    //volume
                    primoNumero = Convert.ToDouble(txt1.Text);
                    totale = Math.Pow(primoNumero, 3);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = Convert.ToString(primoNumero) + "^3";
                    txtRisultato.Text = Convert.ToString(totale);
                    cuboV = false;
                }
                if (cuboS)
                {
                    //superficie
                    primoNumero = Convert.ToDouble(txt1.Text);
                    totale = 6 * (Math.Pow(primoNumero, 2));
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "6 * " + Convert.ToString(primoNumero) + "^2";
                    txtRisultato.Text = Convert.ToString(totale);
                    cuboS = false;
                }
                //CILINDRO
                if (cilindroV)
                {
                    //volume
                    primoNumero = Convert.ToDouble(txt1.Text);
                    secondoNumero = Convert.ToDouble(txt2.Text);
                    totale = (Math.PI * (Math.Pow(secondoNumero, 2)) * primoNumero);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "π * " + Convert.ToString(secondoNumero) + "^2 * " + Convert.ToString(primoNumero);
                    txtRisultato.Text = Convert.ToString(totale);
                    cilindroV = false;
                }
                if (cilindroS)
                {
                    //superficie
                    primoNumero = Convert.ToDouble(txt1.Text);
                    secondoNumero = Convert.ToDouble(txt2.Text);
                    totale = 2 * Math.PI * secondoNumero * primoNumero;
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "2 * π * " + Convert.ToString(secondoNumero) + " * " + Convert.ToString(primoNumero);
                    txtRisultato.Text = Convert.ToString(totale);
                    cilindroS = false;
                }
                //SFERA
                if (sferaV)
                {
                    //volume
                    primoNumero = Convert.ToDouble(txt1.Text);
                    secondoNumero = Convert.ToDouble(txt2.Text);
                    totale = (4.0 / 3.0) * Math.PI * Math.Pow(secondoNumero, 2);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "4 / 3 * π * " + Convert.ToString(secondoNumero) + "^2";
                    txtRisultato.Text = Convert.ToString(totale);
                    sferaV = false;
                }
                if (sferaS)
                {
                    //superficie
                    primoNumero = Convert.ToDouble(txt1.Text);
                    secondoNumero = Convert.ToDouble(txt2.Text);
                    totale = 4 * Math.PI * Math.Pow(secondoNumero, 2);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "4 * π * " + Convert.ToString(secondoNumero) + "^2";
                    txtRisultato.Text = Convert.ToString(totale);
                    sferaS = false;
                }
                //PARALLELEPIPEDO
                if (parallelepipedoV)
                {
                    //volume
                    primoNumero = Convert.ToDouble(txt1.Text);
                    secondoNumero = Convert.ToDouble(txt2.Text);
                    terzoNumero = Convert.ToDouble(txt3.Text);
                    totale = 2 * ((primoNumero * secondoNumero) + terzoNumero);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "2 * ((" + Convert.ToString(primoNumero) + " * " + Convert.ToString(secondoNumero) + ") + " + Convert.ToString(terzoNumero) + ")";
                    txtRisultato.Text = Convert.ToString(totale);
                }
                if (parallelepipedoS)
                {
                    //superficie
                    primoNumero = Convert.ToDouble(txt1.Text);
                    secondoNumero = Convert.ToDouble(txt2.Text);
                    terzoNumero = Convert.ToDouble(txt3.Text);
                    totale = 2 * ((primoNumero * secondoNumero) + (primoNumero * terzoNumero) + (secondoNumero * terzoNumero));
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "2 * ((" + Convert.ToString(primoNumero) + " * " + Convert.ToString(secondoNumero) + ") + (" + Convert.ToString(primoNumero) + " * " + Convert.ToString(terzoNumero) + ") + (" + Convert.ToString(secondoNumero) + " * " + Convert.ToString(terzoNumero) + "))";
                    txtRisultato.Text = Convert.ToString(totale);
                }
            }                
        }
        private void btnChiudi_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
