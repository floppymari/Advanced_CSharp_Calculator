﻿namespace primo_form
{
    partial class frmPrimaFinestra
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new System.Windows.Forms.TextBox();
            this.bottone1 = new System.Windows.Forms.Button();
            this.bottone2 = new System.Windows.Forms.Button();
            this.bottone3 = new System.Windows.Forms.Button();
            this.bottone4 = new System.Windows.Forms.Button();
            this.bottone5 = new System.Windows.Forms.Button();
            this.bottone6 = new System.Windows.Forms.Button();
            this.bottone7 = new System.Windows.Forms.Button();
            this.bottone8 = new System.Windows.Forms.Button();
            this.bottone9 = new System.Windows.Forms.Button();
            this.bottone0 = new System.Windows.Forms.Button();
            this.btnSOMMA = new System.Windows.Forms.Button();
            this.btnSOTTRAZIONE = new System.Windows.Forms.Button();
            this.btnMOLTIPLICAZIONE = new System.Windows.Forms.Button();
            this.btnDIVISIONE = new System.Windows.Forms.Button();
            this.btnRISULTATO = new System.Windows.Forms.Button();
            this.lblOperazione = new System.Windows.Forms.Label();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.grbCalcolatriceBase = new System.Windows.Forms.GroupBox();
            this.grbGeometria = new System.Windows.Forms.GroupBox();
            this.btnGeometriaPiana = new System.Windows.Forms.Button();
            this.btnGeometriaSolidaComp = new System.Windows.Forms.Button();
            this.cmbSceltaFigura = new System.Windows.Forms.ComboBox();
            this.btnGeometriaSolita = new System.Windows.Forms.Button();
            this.rdbPerimetro = new System.Windows.Forms.RadioButton();
            this.rdbArea = new System.Windows.Forms.RadioButton();
            this.grbScientifica = new System.Windows.Forms.GroupBox();
            this.chkTangente = new System.Windows.Forms.CheckBox();
            this.chkCoseno = new System.Windows.Forms.CheckBox();
            this.chkSeno = new System.Windows.Forms.CheckBox();
            this.chkFattoriale = new System.Windows.Forms.CheckBox();
            this.chkPotenze = new System.Windows.Forms.CheckBox();
            this.chkRadiceQuadrata = new System.Windows.Forms.CheckBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblValoreA = new System.Windows.Forms.Label();
            this.lblValoreB = new System.Windows.Forms.Label();
            this.txtRisultato = new System.Windows.Forms.TextBox();
            this.gbOperazioni = new System.Windows.Forms.GroupBox();
            this.rdbBaseScieGeo = new System.Windows.Forms.RadioButton();
            this.rdbGeometrica = new System.Windows.Forms.RadioButton();
            this.rdbEntrambe = new System.Windows.Forms.RadioButton();
            this.rdbScientifica = new System.Windows.Forms.RadioButton();
            this.rdbBase = new System.Windows.Forms.RadioButton();
            this.grbBase = new System.Windows.Forms.GroupBox();
            this.lblAZZERA = new System.Windows.Forms.Label();
            this.mnuCalcolatrice = new System.Windows.Forms.MenuStrip();
            this.menuGestioneDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestioneStringheToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestioneGestioneFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grbCalcolatriceBase.SuspendLayout();
            this.grbGeometria.SuspendLayout();
            this.grbScientifica.SuspendLayout();
            this.gbOperazioni.SuspendLayout();
            this.grbBase.SuspendLayout();
            this.mnuCalcolatrice.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.BackColor = System.Drawing.Color.Thistle;
            this.textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox.ForeColor = System.Drawing.Color.DarkViolet;
            this.textBox.Location = new System.Drawing.Point(153, 52);
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(152, 51);
            this.textBox.TabIndex = 0;
            this.textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bottone1
            // 
            this.bottone1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone1.Location = new System.Drawing.Point(34, 32);
            this.bottone1.Name = "bottone1";
            this.bottone1.Size = new System.Drawing.Size(75, 23);
            this.bottone1.TabIndex = 2;
            this.bottone1.Text = "1";
            this.bottone1.UseVisualStyleBackColor = false;
            this.bottone1.Click += new System.EventHandler(this.bottone1_Click);
            // 
            // bottone2
            // 
            this.bottone2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone2.Location = new System.Drawing.Point(194, 32);
            this.bottone2.Name = "bottone2";
            this.bottone2.Size = new System.Drawing.Size(75, 23);
            this.bottone2.TabIndex = 3;
            this.bottone2.Text = "2";
            this.bottone2.UseVisualStyleBackColor = false;
            this.bottone2.Click += new System.EventHandler(this.bottone2_Click);
            // 
            // bottone3
            // 
            this.bottone3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone3.Location = new System.Drawing.Point(337, 32);
            this.bottone3.Name = "bottone3";
            this.bottone3.Size = new System.Drawing.Size(75, 23);
            this.bottone3.TabIndex = 4;
            this.bottone3.Text = "3";
            this.bottone3.UseVisualStyleBackColor = false;
            this.bottone3.Click += new System.EventHandler(this.bottone3_Click);
            // 
            // bottone4
            // 
            this.bottone4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone4.Location = new System.Drawing.Point(34, 77);
            this.bottone4.Name = "bottone4";
            this.bottone4.Size = new System.Drawing.Size(75, 23);
            this.bottone4.TabIndex = 5;
            this.bottone4.Text = "4";
            this.bottone4.UseVisualStyleBackColor = false;
            this.bottone4.Click += new System.EventHandler(this.bottone4_Click);
            // 
            // bottone5
            // 
            this.bottone5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone5.Location = new System.Drawing.Point(194, 77);
            this.bottone5.Name = "bottone5";
            this.bottone5.Size = new System.Drawing.Size(75, 23);
            this.bottone5.TabIndex = 6;
            this.bottone5.Text = "5";
            this.bottone5.UseVisualStyleBackColor = false;
            this.bottone5.Click += new System.EventHandler(this.bottone5_Click);
            // 
            // bottone6
            // 
            this.bottone6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone6.Location = new System.Drawing.Point(337, 77);
            this.bottone6.Name = "bottone6";
            this.bottone6.Size = new System.Drawing.Size(75, 23);
            this.bottone6.TabIndex = 7;
            this.bottone6.Text = "6";
            this.bottone6.UseVisualStyleBackColor = false;
            this.bottone6.Click += new System.EventHandler(this.bottone6_Click);
            // 
            // bottone7
            // 
            this.bottone7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone7.Location = new System.Drawing.Point(34, 129);
            this.bottone7.Name = "bottone7";
            this.bottone7.Size = new System.Drawing.Size(75, 23);
            this.bottone7.TabIndex = 8;
            this.bottone7.Text = "7";
            this.bottone7.UseVisualStyleBackColor = false;
            this.bottone7.Click += new System.EventHandler(this.bottone7_Click);
            // 
            // bottone8
            // 
            this.bottone8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone8.Location = new System.Drawing.Point(194, 129);
            this.bottone8.Name = "bottone8";
            this.bottone8.Size = new System.Drawing.Size(75, 23);
            this.bottone8.TabIndex = 9;
            this.bottone8.Text = "8";
            this.bottone8.UseVisualStyleBackColor = false;
            this.bottone8.Click += new System.EventHandler(this.bottone8_Click);
            // 
            // bottone9
            // 
            this.bottone9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone9.Location = new System.Drawing.Point(337, 129);
            this.bottone9.Name = "bottone9";
            this.bottone9.Size = new System.Drawing.Size(75, 23);
            this.bottone9.TabIndex = 10;
            this.bottone9.Text = "9";
            this.bottone9.UseVisualStyleBackColor = false;
            this.bottone9.Click += new System.EventHandler(this.bottone9_Click);
            // 
            // bottone0
            // 
            this.bottone0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bottone0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bottone0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.bottone0.Location = new System.Drawing.Point(194, 185);
            this.bottone0.Name = "bottone0";
            this.bottone0.Size = new System.Drawing.Size(75, 23);
            this.bottone0.TabIndex = 11;
            this.bottone0.Text = "0";
            this.bottone0.UseVisualStyleBackColor = false;
            this.bottone0.Click += new System.EventHandler(this.bottone0_Click);
            // 
            // btnSOMMA
            // 
            this.btnSOMMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSOMMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSOMMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSOMMA.Location = new System.Drawing.Point(27, 27);
            this.btnSOMMA.Name = "btnSOMMA";
            this.btnSOMMA.Size = new System.Drawing.Size(45, 41);
            this.btnSOMMA.TabIndex = 12;
            this.btnSOMMA.Text = "+";
            this.btnSOMMA.UseVisualStyleBackColor = false;
            this.btnSOMMA.Click += new System.EventHandler(this.btnSOMMA_Click);
            // 
            // btnSOTTRAZIONE
            // 
            this.btnSOTTRAZIONE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSOTTRAZIONE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSOTTRAZIONE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnSOTTRAZIONE.Location = new System.Drawing.Point(27, 74);
            this.btnSOTTRAZIONE.Name = "btnSOTTRAZIONE";
            this.btnSOTTRAZIONE.Size = new System.Drawing.Size(44, 41);
            this.btnSOTTRAZIONE.TabIndex = 13;
            this.btnSOTTRAZIONE.Text = "-";
            this.btnSOTTRAZIONE.UseVisualStyleBackColor = false;
            this.btnSOTTRAZIONE.Click += new System.EventHandler(this.btnSOTTRAZIONE_Click);
            // 
            // btnMOLTIPLICAZIONE
            // 
            this.btnMOLTIPLICAZIONE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnMOLTIPLICAZIONE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMOLTIPLICAZIONE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnMOLTIPLICAZIONE.Location = new System.Drawing.Point(27, 121);
            this.btnMOLTIPLICAZIONE.Name = "btnMOLTIPLICAZIONE";
            this.btnMOLTIPLICAZIONE.Size = new System.Drawing.Size(45, 36);
            this.btnMOLTIPLICAZIONE.TabIndex = 14;
            this.btnMOLTIPLICAZIONE.Text = "*";
            this.btnMOLTIPLICAZIONE.UseVisualStyleBackColor = false;
            this.btnMOLTIPLICAZIONE.Click += new System.EventHandler(this.btnMOLTIPLICAZIONE_Click);
            // 
            // btnDIVISIONE
            // 
            this.btnDIVISIONE.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnDIVISIONE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDIVISIONE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnDIVISIONE.Location = new System.Drawing.Point(27, 163);
            this.btnDIVISIONE.Name = "btnDIVISIONE";
            this.btnDIVISIONE.Size = new System.Drawing.Size(45, 35);
            this.btnDIVISIONE.TabIndex = 15;
            this.btnDIVISIONE.Text = "/";
            this.btnDIVISIONE.UseVisualStyleBackColor = false;
            this.btnDIVISIONE.Click += new System.EventHandler(this.btnDIVISIONE_Click);
            // 
            // btnRISULTATO
            // 
            this.btnRISULTATO.BackColor = System.Drawing.Color.Plum;
            this.btnRISULTATO.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRISULTATO.ForeColor = System.Drawing.Color.DarkOrchid;
            this.btnRISULTATO.Location = new System.Drawing.Point(504, 91);
            this.btnRISULTATO.Name = "btnRISULTATO";
            this.btnRISULTATO.Size = new System.Drawing.Size(68, 42);
            this.btnRISULTATO.TabIndex = 16;
            this.btnRISULTATO.Text = "=";
            this.btnRISULTATO.UseVisualStyleBackColor = false;
            this.btnRISULTATO.Click += new System.EventHandler(this.btnRISULTATO_Click);
            // 
            // lblOperazione
            // 
            this.lblOperazione.AutoSize = true;
            this.lblOperazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperazione.Location = new System.Drawing.Point(639, 39);
            this.lblOperazione.Name = "lblOperazione";
            this.lblOperazione.Size = new System.Drawing.Size(0, 25);
            this.lblOperazione.TabIndex = 17;
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAzzera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAzzera.Location = new System.Drawing.Point(838, 80);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(92, 53);
            this.btnAzzera.TabIndex = 18;
            this.btnAzzera.Text = "AZZERA";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // grbCalcolatriceBase
            // 
            this.grbCalcolatriceBase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.grbCalcolatriceBase.Controls.Add(this.grbGeometria);
            this.grbCalcolatriceBase.Controls.Add(this.bottone9);
            this.grbCalcolatriceBase.Controls.Add(this.grbScientifica);
            this.grbCalcolatriceBase.Controls.Add(this.bottone1);
            this.grbCalcolatriceBase.Controls.Add(this.bottone2);
            this.grbCalcolatriceBase.Controls.Add(this.bottone3);
            this.grbCalcolatriceBase.Controls.Add(this.bottone4);
            this.grbCalcolatriceBase.Controls.Add(this.bottone5);
            this.grbCalcolatriceBase.Controls.Add(this.bottone6);
            this.grbCalcolatriceBase.Controls.Add(this.bottone7);
            this.grbCalcolatriceBase.Controls.Add(this.bottone0);
            this.grbCalcolatriceBase.Controls.Add(this.bottone8);
            this.grbCalcolatriceBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbCalcolatriceBase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.grbCalcolatriceBase.Location = new System.Drawing.Point(30, 247);
            this.grbCalcolatriceBase.Name = "grbCalcolatriceBase";
            this.grbCalcolatriceBase.Size = new System.Drawing.Size(899, 227);
            this.grbCalcolatriceBase.TabIndex = 19;
            this.grbCalcolatriceBase.TabStop = false;
            this.grbCalcolatriceBase.Text = "Calcolatrice Base";
            // 
            // grbGeometria
            // 
            this.grbGeometria.BackColor = System.Drawing.Color.PowderBlue;
            this.grbGeometria.Controls.Add(this.btnGeometriaPiana);
            this.grbGeometria.Controls.Add(this.btnGeometriaSolidaComp);
            this.grbGeometria.Controls.Add(this.cmbSceltaFigura);
            this.grbGeometria.Controls.Add(this.btnGeometriaSolita);
            this.grbGeometria.Controls.Add(this.rdbPerimetro);
            this.grbGeometria.Controls.Add(this.rdbArea);
            this.grbGeometria.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbGeometria.ForeColor = System.Drawing.Color.DarkCyan;
            this.grbGeometria.Location = new System.Drawing.Point(683, 11);
            this.grbGeometria.Name = "grbGeometria";
            this.grbGeometria.Size = new System.Drawing.Size(201, 210);
            this.grbGeometria.TabIndex = 25;
            this.grbGeometria.TabStop = false;
            this.grbGeometria.Text = "Geometria";
            // 
            // btnGeometriaPiana
            // 
            this.btnGeometriaPiana.BackColor = System.Drawing.Color.CadetBlue;
            this.btnGeometriaPiana.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeometriaPiana.ForeColor = System.Drawing.Color.Azure;
            this.btnGeometriaPiana.Location = new System.Drawing.Point(7, 175);
            this.btnGeometriaPiana.Name = "btnGeometriaPiana";
            this.btnGeometriaPiana.Size = new System.Drawing.Size(188, 29);
            this.btnGeometriaPiana.TabIndex = 26;
            this.btnGeometriaPiana.Text = "geometria piana";
            this.btnGeometriaPiana.UseVisualStyleBackColor = false;
            this.btnGeometriaPiana.Click += new System.EventHandler(this.btnGeometriaPiana_Click);
            // 
            // btnGeometriaSolidaComp
            // 
            this.btnGeometriaSolidaComp.BackColor = System.Drawing.Color.CadetBlue;
            this.btnGeometriaSolidaComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeometriaSolidaComp.ForeColor = System.Drawing.Color.Azure;
            this.btnGeometriaSolidaComp.Location = new System.Drawing.Point(102, 105);
            this.btnGeometriaSolidaComp.Name = "btnGeometriaSolidaComp";
            this.btnGeometriaSolidaComp.Size = new System.Drawing.Size(93, 65);
            this.btnGeometriaSolidaComp.TabIndex = 25;
            this.btnGeometriaSolidaComp.Text = "geometria solida COMPITO";
            this.btnGeometriaSolidaComp.UseVisualStyleBackColor = false;
            this.btnGeometriaSolidaComp.Click += new System.EventHandler(this.btnGeometriaSolidaComp_Click);
            // 
            // cmbSceltaFigura
            // 
            this.cmbSceltaFigura.FormattingEnabled = true;
            this.cmbSceltaFigura.Items.AddRange(new object[] {
            "Rettangolo",
            "Quadrato",
            "Rombo",
            "Parallelogramma",
            "Cerchio"});
            this.cmbSceltaFigura.Location = new System.Drawing.Point(7, 21);
            this.cmbSceltaFigura.Name = "cmbSceltaFigura";
            this.cmbSceltaFigura.Size = new System.Drawing.Size(188, 21);
            this.cmbSceltaFigura.TabIndex = 4;
            this.cmbSceltaFigura.SelectedIndexChanged += new System.EventHandler(this.cmbSceltaFigura_SelectedIndexChanged);
            // 
            // btnGeometriaSolita
            // 
            this.btnGeometriaSolita.BackColor = System.Drawing.Color.CadetBlue;
            this.btnGeometriaSolita.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeometriaSolita.ForeColor = System.Drawing.Color.Azure;
            this.btnGeometriaSolita.Location = new System.Drawing.Point(7, 105);
            this.btnGeometriaSolita.Name = "btnGeometriaSolita";
            this.btnGeometriaSolita.Size = new System.Drawing.Size(89, 64);
            this.btnGeometriaSolita.TabIndex = 3;
            this.btnGeometriaSolita.Text = "geometria solida";
            this.btnGeometriaSolita.UseVisualStyleBackColor = false;
            this.btnGeometriaSolita.Click += new System.EventHandler(this.btnGeometriaSolita_Click);
            // 
            // rdbPerimetro
            // 
            this.rdbPerimetro.AutoSize = true;
            this.rdbPerimetro.ForeColor = System.Drawing.Color.DarkCyan;
            this.rdbPerimetro.Location = new System.Drawing.Point(7, 82);
            this.rdbPerimetro.Name = "rdbPerimetro";
            this.rdbPerimetro.Size = new System.Drawing.Size(89, 17);
            this.rdbPerimetro.TabIndex = 2;
            this.rdbPerimetro.TabStop = true;
            this.rdbPerimetro.Text = "PERIMETRO";
            this.rdbPerimetro.UseVisualStyleBackColor = true;
            this.rdbPerimetro.CheckedChanged += new System.EventHandler(this.rdbPerimetro_CheckedChanged);
            // 
            // rdbArea
            // 
            this.rdbArea.AutoSize = true;
            this.rdbArea.ForeColor = System.Drawing.Color.DarkCyan;
            this.rdbArea.Location = new System.Drawing.Point(7, 58);
            this.rdbArea.Name = "rdbArea";
            this.rdbArea.Size = new System.Drawing.Size(54, 17);
            this.rdbArea.TabIndex = 1;
            this.rdbArea.TabStop = true;
            this.rdbArea.Text = "AREA";
            this.rdbArea.UseVisualStyleBackColor = true;
            this.rdbArea.CheckedChanged += new System.EventHandler(this.rdbArea_CheckedChanged);
            // 
            // grbScientifica
            // 
            this.grbScientifica.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.grbScientifica.Controls.Add(this.chkTangente);
            this.grbScientifica.Controls.Add(this.chkCoseno);
            this.grbScientifica.Controls.Add(this.chkSeno);
            this.grbScientifica.Controls.Add(this.chkFattoriale);
            this.grbScientifica.Controls.Add(this.chkPotenze);
            this.grbScientifica.Controls.Add(this.chkRadiceQuadrata);
            this.grbScientifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbScientifica.ForeColor = System.Drawing.Color.DarkGreen;
            this.grbScientifica.Location = new System.Drawing.Point(523, 11);
            this.grbScientifica.Name = "grbScientifica";
            this.grbScientifica.Size = new System.Drawing.Size(153, 210);
            this.grbScientifica.TabIndex = 24;
            this.grbScientifica.TabStop = false;
            this.grbScientifica.Text = "Scientifica";
            // 
            // chkTangente
            // 
            this.chkTangente.AutoSize = true;
            this.chkTangente.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkTangente.Location = new System.Drawing.Point(0, 181);
            this.chkTangente.Name = "chkTangente";
            this.chkTangente.Size = new System.Drawing.Size(102, 17);
            this.chkTangente.TabIndex = 5;
            this.chkTangente.Text = "[tan()] Tangente";
            this.chkTangente.UseVisualStyleBackColor = true;
            this.chkTangente.CheckedChanged += new System.EventHandler(this.chkTangente_CheckedChanged);
            // 
            // chkCoseno
            // 
            this.chkCoseno.AutoSize = true;
            this.chkCoseno.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkCoseno.Location = new System.Drawing.Point(0, 152);
            this.chkCoseno.Name = "chkCoseno";
            this.chkCoseno.Size = new System.Drawing.Size(94, 17);
            this.chkCoseno.TabIndex = 4;
            this.chkCoseno.Text = "[cos()] Coseno";
            this.chkCoseno.UseVisualStyleBackColor = true;
            this.chkCoseno.CheckedChanged += new System.EventHandler(this.chkCoseno_CheckedChanged);
            // 
            // chkSeno
            // 
            this.chkSeno.AutoSize = true;
            this.chkSeno.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkSeno.Location = new System.Drawing.Point(0, 121);
            this.chkSeno.Name = "chkSeno";
            this.chkSeno.Size = new System.Drawing.Size(79, 17);
            this.chkSeno.TabIndex = 3;
            this.chkSeno.Text = "[sin()] Seno";
            this.chkSeno.UseVisualStyleBackColor = true;
            this.chkSeno.CheckedChanged += new System.EventHandler(this.chkSeno_CheckedChanged);
            // 
            // chkFattoriale
            // 
            this.chkFattoriale.AutoSize = true;
            this.chkFattoriale.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkFattoriale.Location = new System.Drawing.Point(0, 89);
            this.chkFattoriale.Name = "chkFattoriale";
            this.chkFattoriale.Size = new System.Drawing.Size(86, 17);
            this.chkFattoriale.TabIndex = 2;
            this.chkFattoriale.Text = "[x!] Fattoriale";
            this.chkFattoriale.UseVisualStyleBackColor = true;
            this.chkFattoriale.CheckedChanged += new System.EventHandler(this.chkFattoriale_CheckedChanged);
            // 
            // chkPotenze
            // 
            this.chkPotenze.AutoSize = true;
            this.chkPotenze.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkPotenze.Location = new System.Drawing.Point(0, 58);
            this.chkPotenze.Name = "chkPotenze";
            this.chkPotenze.Size = new System.Drawing.Size(90, 17);
            this.chkPotenze.TabIndex = 1;
            this.chkPotenze.Text = "[x^y] Potenze";
            this.chkPotenze.UseVisualStyleBackColor = true;
            this.chkPotenze.CheckedChanged += new System.EventHandler(this.chkPotenze_CheckedChanged);
            // 
            // chkRadiceQuadrata
            // 
            this.chkRadiceQuadrata.AutoSize = true;
            this.chkRadiceQuadrata.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkRadiceQuadrata.Location = new System.Drawing.Point(0, 27);
            this.chkRadiceQuadrata.Name = "chkRadiceQuadrata";
            this.chkRadiceQuadrata.Size = new System.Drawing.Size(128, 17);
            this.chkRadiceQuadrata.TabIndex = 0;
            this.chkRadiceQuadrata.Text = "[ √ ] Radice Quadrata";
            this.chkRadiceQuadrata.UseVisualStyleBackColor = true;
            this.chkRadiceQuadrata.CheckedChanged += new System.EventHandler(this.chkRadiceQuadrata_CheckedChanged_1);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Plum;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.LightSlateGray;
            this.textBox3.Location = new System.Drawing.Point(153, 115);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(152, 51);
            this.textBox3.TabIndex = 1;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblValoreA
            // 
            this.lblValoreA.AutoSize = true;
            this.lblValoreA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValoreA.ForeColor = System.Drawing.Color.Thistle;
            this.lblValoreA.Location = new System.Drawing.Point(183, 24);
            this.lblValoreA.Name = "lblValoreA";
            this.lblValoreA.Size = new System.Drawing.Size(102, 25);
            this.lblValoreA.TabIndex = 20;
            this.lblValoreA.Text = "Valore A";
            // 
            // lblValoreB
            // 
            this.lblValoreB.AutoSize = true;
            this.lblValoreB.BackColor = System.Drawing.Color.LavenderBlush;
            this.lblValoreB.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValoreB.ForeColor = System.Drawing.Color.MediumOrchid;
            this.lblValoreB.Location = new System.Drawing.Point(183, 169);
            this.lblValoreB.Name = "lblValoreB";
            this.lblValoreB.Size = new System.Drawing.Size(102, 25);
            this.lblValoreB.TabIndex = 21;
            this.lblValoreB.Text = "Valore B";
            // 
            // txtRisultato
            // 
            this.txtRisultato.Location = new System.Drawing.Point(636, 77);
            this.txtRisultato.Multiline = true;
            this.txtRisultato.Name = "txtRisultato";
            this.txtRisultato.Size = new System.Drawing.Size(139, 64);
            this.txtRisultato.TabIndex = 22;
            // 
            // gbOperazioni
            // 
            this.gbOperazioni.BackColor = System.Drawing.Color.Pink;
            this.gbOperazioni.Controls.Add(this.rdbBaseScieGeo);
            this.gbOperazioni.Controls.Add(this.rdbGeometrica);
            this.gbOperazioni.Controls.Add(this.rdbEntrambe);
            this.gbOperazioni.Controls.Add(this.rdbScientifica);
            this.gbOperazioni.Controls.Add(this.rdbBase);
            this.gbOperazioni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbOperazioni.ForeColor = System.Drawing.Color.DeepPink;
            this.gbOperazioni.Location = new System.Drawing.Point(30, 192);
            this.gbOperazioni.Name = "gbOperazioni";
            this.gbOperazioni.Size = new System.Drawing.Size(744, 49);
            this.gbOperazioni.TabIndex = 23;
            this.gbOperazioni.TabStop = false;
            this.gbOperazioni.Text = "Scelta Operazioni";
            // 
            // rdbBaseScieGeo
            // 
            this.rdbBaseScieGeo.AutoSize = true;
            this.rdbBaseScieGeo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbBaseScieGeo.Location = new System.Drawing.Point(623, 20);
            this.rdbBaseScieGeo.Name = "rdbBaseScieGeo";
            this.rdbBaseScieGeo.Size = new System.Drawing.Size(114, 17);
            this.rdbBaseScieGeo.TabIndex = 4;
            this.rdbBaseScieGeo.TabStop = true;
            this.rdbBaseScieGeo.Text = "Tutte le calcolatrici";
            this.rdbBaseScieGeo.UseVisualStyleBackColor = true;
            this.rdbBaseScieGeo.CheckedChanged += new System.EventHandler(this.rdbBaseScieGeo_CheckedChanged);
            // 
            // rdbGeometrica
            // 
            this.rdbGeometrica.AutoSize = true;
            this.rdbGeometrica.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbGeometrica.Location = new System.Drawing.Point(465, 19);
            this.rdbGeometrica.Name = "rdbGeometrica";
            this.rdbGeometrica.Size = new System.Drawing.Size(137, 17);
            this.rdbGeometrica.TabIndex = 3;
            this.rdbGeometrica.TabStop = true;
            this.rdbGeometrica.Text = "Calcolatrice Geometrica";
            this.rdbGeometrica.UseVisualStyleBackColor = true;
            this.rdbGeometrica.CheckedChanged += new System.EventHandler(this.rdbGeometrica_CheckedChanged);
            // 
            // rdbEntrambe
            // 
            this.rdbEntrambe.AutoSize = true;
            this.rdbEntrambe.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbEntrambe.Location = new System.Drawing.Point(277, 20);
            this.rdbEntrambe.Name = "rdbEntrambe";
            this.rdbEntrambe.Size = new System.Drawing.Size(168, 17);
            this.rdbEntrambe.TabIndex = 2;
            this.rdbEntrambe.TabStop = true;
            this.rdbEntrambe.Text = "Calcolatrice Base + Scientifica";
            this.rdbEntrambe.UseVisualStyleBackColor = true;
            this.rdbEntrambe.CheckedChanged += new System.EventHandler(this.rdbEntrambe_CheckedChanged);
            // 
            // rdbScientifica
            // 
            this.rdbScientifica.AutoSize = true;
            this.rdbScientifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbScientifica.Location = new System.Drawing.Point(123, 20);
            this.rdbScientifica.Name = "rdbScientifica";
            this.rdbScientifica.Size = new System.Drawing.Size(132, 17);
            this.rdbScientifica.TabIndex = 1;
            this.rdbScientifica.TabStop = true;
            this.rdbScientifica.Text = "Calcolatrice Scientifica";
            this.rdbScientifica.UseVisualStyleBackColor = true;
            this.rdbScientifica.CheckedChanged += new System.EventHandler(this.rdbScientifica_CheckedChanged);
            // 
            // rdbBase
            // 
            this.rdbBase.AutoSize = true;
            this.rdbBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbBase.Location = new System.Drawing.Point(0, 19);
            this.rdbBase.Name = "rdbBase";
            this.rdbBase.Size = new System.Drawing.Size(107, 17);
            this.rdbBase.TabIndex = 0;
            this.rdbBase.TabStop = true;
            this.rdbBase.Text = "Calcolatrice Base";
            this.rdbBase.UseVisualStyleBackColor = true;
            this.rdbBase.CheckedChanged += new System.EventHandler(this.rdbBase_CheckedChanged);
            // 
            // grbBase
            // 
            this.grbBase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.grbBase.Controls.Add(this.btnDIVISIONE);
            this.grbBase.Controls.Add(this.btnSOMMA);
            this.grbBase.Controls.Add(this.btnSOTTRAZIONE);
            this.grbBase.Controls.Add(this.btnMOLTIPLICAZIONE);
            this.grbBase.ForeColor = System.Drawing.Color.Olive;
            this.grbBase.Location = new System.Drawing.Point(448, 258);
            this.grbBase.Name = "grbBase";
            this.grbBase.Size = new System.Drawing.Size(99, 210);
            this.grbBase.TabIndex = 16;
            this.grbBase.TabStop = false;
            this.grbBase.Text = "Operazioni Base";
            // 
            // lblAZZERA
            // 
            this.lblAZZERA.AutoSize = true;
            this.lblAZZERA.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAZZERA.Location = new System.Drawing.Point(836, 68);
            this.lblAZZERA.Name = "lblAZZERA";
            this.lblAZZERA.Size = new System.Drawing.Size(94, 9);
            this.lblAZZERA.TabIndex = 24;
            this.lblAZZERA.Text = "CLICCARE 2 VOLTE";
            // 
            // mnuCalcolatrice
            // 
            this.mnuCalcolatrice.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuGestioneDateToolStripMenuItem,
            this.gestioneStringheToolStripMenuItem,
            this.gestioneGestioneFilesToolStripMenuItem});
            this.mnuCalcolatrice.Location = new System.Drawing.Point(0, 0);
            this.mnuCalcolatrice.Name = "mnuCalcolatrice";
            this.mnuCalcolatrice.Size = new System.Drawing.Size(976, 24);
            this.mnuCalcolatrice.TabIndex = 25;
            this.mnuCalcolatrice.Text = "menu calcolatrice";
            this.mnuCalcolatrice.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.mnuCalcolatrice_ItemClicked);
            // 
            // menuGestioneDateToolStripMenuItem
            // 
            this.menuGestioneDateToolStripMenuItem.Name = "menuGestioneDateToolStripMenuItem";
            this.menuGestioneDateToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.menuGestioneDateToolStripMenuItem.Text = "gestione date";
            this.menuGestioneDateToolStripMenuItem.Click += new System.EventHandler(this.menuGestioneDateToolStripMenuItem_Click);
            // 
            // gestioneStringheToolStripMenuItem
            // 
            this.gestioneStringheToolStripMenuItem.Name = "gestioneStringheToolStripMenuItem";
            this.gestioneStringheToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.gestioneStringheToolStripMenuItem.Text = "gestione stringhe";
            this.gestioneStringheToolStripMenuItem.Click += new System.EventHandler(this.gestioneStringheToolStripMenuItem_Click);
            // 
            // gestioneGestioneFilesToolStripMenuItem
            // 
            this.gestioneGestioneFilesToolStripMenuItem.Name = "gestioneGestioneFilesToolStripMenuItem";
            this.gestioneGestioneFilesToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.gestioneGestioneFilesToolStripMenuItem.Text = "gestione files";
            this.gestioneGestioneFilesToolStripMenuItem.Click += new System.EventHandler(this.gestioneGestioneFilesToolStripMenuItem_Click);
            // 
            // frmPrimaFinestra
            // 
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(976, 507);
            this.Controls.Add(this.lblAZZERA);
            this.Controls.Add(this.grbBase);
            this.Controls.Add(this.gbOperazioni);
            this.Controls.Add(this.txtRisultato);
            this.Controls.Add(this.lblValoreB);
            this.Controls.Add(this.lblValoreA);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.grbCalcolatriceBase);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.lblOperazione);
            this.Controls.Add(this.btnRISULTATO);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.mnuCalcolatrice);
            this.MainMenuStrip = this.mnuCalcolatrice;
            this.Name = "frmPrimaFinestra";
            this.Text = "Calcolatrice";
            this.grbCalcolatriceBase.ResumeLayout(false);
            this.grbGeometria.ResumeLayout(false);
            this.grbGeometria.PerformLayout();
            this.grbScientifica.ResumeLayout(false);
            this.grbScientifica.PerformLayout();
            this.gbOperazioni.ResumeLayout(false);
            this.gbOperazioni.PerformLayout();
            this.grbBase.ResumeLayout(false);
            this.mnuCalcolatrice.ResumeLayout(false);
            this.mnuCalcolatrice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCasellaTesto;
        private System.Windows.Forms.Button btnCliccami;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button buttonCliccami;
        private System.Windows.Forms.TextBox txtPrimoTesto;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button bottone1;
        private System.Windows.Forms.Button bottone2;
        private System.Windows.Forms.Button bottone3;
        private System.Windows.Forms.Button bottone4;
        private System.Windows.Forms.Button bottone5;
        private System.Windows.Forms.Button bottone6;
        private System.Windows.Forms.Button bottone7;
        private System.Windows.Forms.Button bottone8;
        private System.Windows.Forms.Button bottone9;
        private System.Windows.Forms.Button bottone0;
        private System.Windows.Forms.Button btnSOMMA;
        private System.Windows.Forms.Button btnSOTTRAZIONE;
        private System.Windows.Forms.Button btnMOLTIPLICAZIONE;
        private System.Windows.Forms.Button btnDIVISIONE;
        private System.Windows.Forms.Button btnRISULTATO;
        private System.Windows.Forms.Label lblOperazione;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.GroupBox grbCalcolatriceBase;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lblValoreA;
        private System.Windows.Forms.Label lblValoreB;
        private System.Windows.Forms.TextBox txtRisultato;
        private System.Windows.Forms.GroupBox gbOperazioni;
        private System.Windows.Forms.RadioButton rdbBase;
        private System.Windows.Forms.RadioButton rdbScientifica;
        private System.Windows.Forms.GroupBox grbScientifica;
        private System.Windows.Forms.CheckBox chkRadiceQuadrata;
        private System.Windows.Forms.CheckBox chkTangente;
        private System.Windows.Forms.CheckBox chkCoseno;
        private System.Windows.Forms.CheckBox chkSeno;
        private System.Windows.Forms.CheckBox chkFattoriale;
        private System.Windows.Forms.CheckBox chkPotenze;
        private System.Windows.Forms.GroupBox grbBase;
        private System.Windows.Forms.RadioButton rdbEntrambe;
        private System.Windows.Forms.GroupBox grbGeometria;
        private System.Windows.Forms.Button btnGeometriaSolita;
        private System.Windows.Forms.RadioButton rdbPerimetro;
        private System.Windows.Forms.RadioButton rdbArea;
        private System.Windows.Forms.ComboBox cmbSceltaFigura;
        private System.Windows.Forms.RadioButton rdbBaseScieGeo;
        private System.Windows.Forms.RadioButton rdbGeometrica;
        private System.Windows.Forms.Label lblAZZERA;
        private System.Windows.Forms.Button btnGeometriaSolidaComp;
        private System.Windows.Forms.MenuStrip mnuCalcolatrice;
        private System.Windows.Forms.ToolStripMenuItem menuGestioneDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestioneStringheToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestioneGestioneFilesToolStripMenuItem;
        private System.Windows.Forms.Button btnGeometriaPiana;
    }
}

