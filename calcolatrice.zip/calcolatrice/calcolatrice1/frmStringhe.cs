﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace primo_form
{
    public partial class frmStringhe : Form
    {
        public frmStringhe()
        {
            InitializeComponent();
            txt1.Focus();
            //parto con la seconda textbox disattivata di dafault
            lblStringaDue.Enabled = false;
            txt2.Enabled = false;
            //si inizia con gli rdb a false
            rdbLunghezza.Checked = false;
            rdbMaiuscolo.Checked = false;
            rdbMinuscolo.Checked = false;
            rdbContiene.Checked = false;
            rdbConcatenazione.Checked = false;
            rdbIndiceCarattere.Checked = false;
            rdbCarattereIndice.Checked = false;
            rdbInizia.Checked = false;
            rdbFinisce.Checked = false;
        }

        //dichiarazioni
        bool lunghezza = false;
        bool maiuscolo = false;
        bool minuscolo = false;
        bool contiene = false;
        bool concatenazione = false;
        bool indiceCarattere = false;
        bool carattereIndice = false;
        bool inizia = false;
        bool finisce = false;

        //bottone azzera e risultato
        private void btnAzzera_Click(object sender, EventArgs e)
        {
            //reimpostazione dei booleani
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = false;

            //azzeramento delle text box
            txt1.Text = "";
            txt2.Text = "";
            txtRisultato.Text = "";

            //ripristino della visibilità dei controlli
            txt1.Visible = true;
            lblStringaUno.Visible = true;
            txt2.Enabled = false;
            lblStringaDue.Enabled = false;

            //deselezione dei RadioButton
            rdbLunghezza.Checked = false;
            rdbMaiuscolo.Checked = false;
            rdbMinuscolo.Checked = false;
            rdbContiene.Checked = false;
            rdbConcatenazione.Checked = false;
            rdbIndiceCarattere.Checked = false;
            rdbCarattereIndice.Checked = false;
            rdbInizia.Checked = false;
            rdbFinisce.Checked = false;

            //focalizzazione sulla primaa text box
            txt1.Focus();
        }
        private void btnRisultato_Click(object sender, EventArgs e)
        {
            if (lunghezza == true)
            {
                txtRisultato.Text = txt1.TextLength.ToString();
            }
            
            if (maiuscolo == true)
            {
                txtRisultato.Text = txt1.Text.ToUpper();
            }

            if (minuscolo == true)
            {
                txtRisultato.Text = txt1.Text.ToLower();
            }

            if (contiene == true)
            {
                bool isContenuta = txt1.Text.Contains(txt2.Text);

                if (isContenuta)
                {
                    txtRisultato.Text = "Vero";
                }
                else
                {
                    txtRisultato.Text = "Falso";
                }

                rdbContiene.Checked = false;
            }

            if (concatenazione == true)
            {
                txtRisultato.Text = txt1.Text + "  " + txt2.Text;
                rdbConcatenazione.Checked = false;
            }

            if (indiceCarattere == true)
            {
                int indice = 0;

                indice = txt1.Text.IndexOf(txt2.Text);
                txtRisultato.Text = indice.ToString();
                rdbIndiceCarattere.Checked = false;
            }

            if (carattereIndice == true) //da sistemare
            {
                char carattere = ' ';

                carattere = txt1.Text[Convert.ToInt32(txt1.Text)];
                txtRisultato.Text = carattere.ToString();
                rdbCarattereIndice.Checked = false;
            }

            if (inizia == true)
            {
                bool isInizio = txt1.Text.StartsWith(txt2.Text);

                if (isInizio)
                {
                    txtRisultato.Text = "Vero";
                }
                else
                {
                    txtRisultato.Text = "Falso";
                }                   
            }

            if (finisce == true)
            {
                bool isFine = txt1.Text.EndsWith(txt2.Text);

                if (isFine)
                {
                    txtRisultato.Text = "Vero";
                }
                else
                {
                    txtRisultato.Text = "Falso";
                }
            }
        }

        //gestione dei radio button
        private void rdbLunghezza_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = true;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = false;
            txt2.Enabled = false;
        }
        private void rdbMaiuscolo_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = true;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = false;
            txt2.Enabled = false;
        }
        private void rdbMinuscolo_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = true;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = false;
            txt2.Enabled = false;
        }
        private void rdbContiene_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = true;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = true;
            txt2.Enabled = true;
        }
        private void rdbConcatenazione_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = true;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = true;
            txt2.Enabled = true;
        }
        private void rdbIndiceCarattere_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = true;
            carattereIndice = false;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = true;
            txt2.Enabled = true;
        }
        private void rdbCarattereIndice_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = true;
            inizia = false;
            finisce = false;
            lblStringaDue.Enabled = true;
            txt2.Enabled = true;
        }
        private void rdbInizia_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = true;
            finisce = false;
            lblStringaDue.Enabled = true;
            txt2.Enabled = true;
        }
        private void rdbFinisce_CheckedChanged(object sender, EventArgs e)
        {
            lunghezza = false;
            maiuscolo = false;
            minuscolo = false;
            contiene = false;
            concatenazione = false;
            indiceCarattere = false;
            carattereIndice = false;
            inizia = false;
            finisce = true;
            lblStringaDue.Enabled = true;
            txt2.Enabled = true;
        }

        //bottone per tornare alla pagina iniziale
        private void btnChiudi_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
