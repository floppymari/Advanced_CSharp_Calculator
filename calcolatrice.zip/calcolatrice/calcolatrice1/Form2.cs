﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace primo_form
{
    public partial class FrmGeometriaSolidaC : Form
    {
        public FrmGeometriaSolidaC()
        {
            InitializeComponent();
            //parto con i RadioButton a false
            rdbVolume.Checked = false;
            rdbSuperficie.Checked = false;
        }

        //dichiarazioni
        double primoNumero = 0;
        double totale = 0;

        bool cubo = false;
        bool sfera = false;

        //bottone per il risultato e azzera
        private void btnRisultato_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "")
            {
                MessageBox.Show("Devi inserire un valore per proseguire con i calcoli, riparti", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblValoreA.Text = "Valore A";
                cmbSceltaFigura.Text = "";
                rdbVolume.Checked = false;
                rdbSuperficie.Checked = false;
                txt1.Focus();
            }

            if (cmbSceltaFigura.Text == "cubo")
            {
                cubo = true;
                //CUBO 
                if (rdbVolume.Checked)
                {
                    //volume
                    primoNumero = Convert.ToDouble(txt1.Text);
                    totale = Math.Pow(primoNumero, 3);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = Convert.ToString(primoNumero) + "^3";
                    txtRisultato.Text = Convert.ToString(totale);
                    cubo = false;
                }
                if (rdbSuperficie.Checked)
                {
                    //superficie
                    primoNumero = Convert.ToDouble(txt1.Text);
                    totale = 6 * (Math.Pow(primoNumero, 2));
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "6 * " + Convert.ToString(primoNumero) + "^2";
                    txtRisultato.Text = Convert.ToString(totale);
                    cubo = false;
                }
            }
            else if (cmbSceltaFigura.Text == "sfera")
            {
                sfera = true;
                //SFERA
                if (rdbVolume.Checked)
                {
                    //volume
                    primoNumero = Convert.ToDouble(txt1.Text);
                    totale = (4.0 / 3.0) * Math.PI * Math.Pow(primoNumero, 2);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "4 / 3 * π * " + Convert.ToString(primoNumero) + "^2";
                    txtRisultato.Text = Convert.ToString(totale);
                    sfera = false;
                }
                if (rdbSuperficie.Checked)
                {
                    //superficie
                    primoNumero = Convert.ToDouble(txt1.Text);
                    totale = 4 * Math.PI * Math.Pow(primoNumero, 2);
                    lblOperazione.Visible = true;
                    lblOperazione.Text = "4 * π * " + Convert.ToString(primoNumero) + "^2";
                    txtRisultato.Text = Convert.ToString(totale);
                    sfera = false;
                }
            }
        }
        private void btnAzzera_Click(object sender, EventArgs e)
        {
            //azzeramento delle variabili numeriche
            primoNumero = 0;
            totale = 0;

            //azzeramento delle TextBox
            txt1.Text = "";
            txtRisultato.Text = "";

            //ripristino della visibilità dei controlli
            txt1.Visible = true;
            lblValoreA.Visible = true;
            lblOperazione.Visible = true;

            //reimpostazione delle etichette e risultati
            lblValoreA.Text = "Valore A";
            lblOperazione.Text = "";

            //deselezione dei RadioButton
            cmbSceltaFigura.Text = "";
            rdbVolume.Checked = false;
            rdbSuperficie.Checked = false;

            //reimpostazione dei booleani
            cubo = false;
            sfera = false;

            //focalizzare la prima TextBox
            txt1.Focus();
        }

        //combobox scelta della figura e radiobutton del volume e superficie
        private void cmbSceltaFigura_SelectedIndexChanged(object sender, EventArgs e)
        {
            cubo = false;
            sfera = false;

            string scelta = cmbSceltaFigura.Text;

            switch (scelta)
            {
                case "cubo":
                    cubo = true;
                    lblValoreA.Text = "lato";
                    txt1.Visible = true;
                    break;

                case "sfera":
                    sfera = true;
                    lblValoreA.Text = "raggio";
                    txt1.Visible = true;
                    break;

                default:
                    break;
            }
        }
        private void rdbVolume_CheckedChanged(object sender, EventArgs e)
        {
            //radio button del volume
        }
        private void rdbSuperficie_CheckedChanged(object sender, EventArgs e)
        {
            //radio button della superficie
        }

        //bottone per ritornare alla pagina iniziale
        private void btnChiudi_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
