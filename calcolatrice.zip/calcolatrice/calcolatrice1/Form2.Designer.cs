﻿namespace primo_form
{
    partial class FrmGeometriaSolidaC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.btnRisultato = new System.Windows.Forms.Button();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lblValoreA = new System.Windows.Forms.Label();
            this.cmbSceltaFigura = new System.Windows.Forms.ComboBox();
            this.grbSceltaFigura = new System.Windows.Forms.GroupBox();
            this.rdbSuperficie = new System.Windows.Forms.RadioButton();
            this.rdbVolume = new System.Windows.Forms.RadioButton();
            this.txtRisultato = new System.Windows.Forms.TextBox();
            this.lblOperazione = new System.Windows.Forms.Label();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.grbSceltaFigura.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnChiudi
            // 
            this.btnChiudi.BackColor = System.Drawing.Color.Thistle;
            this.btnChiudi.Font = new System.Drawing.Font("Papyrus", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiudi.ForeColor = System.Drawing.Color.Purple;
            this.btnChiudi.Location = new System.Drawing.Point(416, 273);
            this.btnChiudi.Name = "btnChiudi";
            this.btnChiudi.Size = new System.Drawing.Size(211, 42);
            this.btnChiudi.TabIndex = 27;
            this.btnChiudi.Text = "<--- CHIUDI E RITORNA";
            this.btnChiudi.UseVisualStyleBackColor = false;
            this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
            // 
            // btnRisultato
            // 
            this.btnRisultato.BackColor = System.Drawing.Color.Thistle;
            this.btnRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRisultato.ForeColor = System.Drawing.Color.Purple;
            this.btnRisultato.Location = new System.Drawing.Point(285, 149);
            this.btnRisultato.Name = "btnRisultato";
            this.btnRisultato.Size = new System.Drawing.Size(106, 51);
            this.btnRisultato.TabIndex = 28;
            this.btnRisultato.Text = "=";
            this.btnRisultato.UseVisualStyleBackColor = false;
            this.btnRisultato.Click += new System.EventHandler(this.btnRisultato_Click);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(461, 80);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(128, 45);
            this.txt1.TabIndex = 29;
            // 
            // lblValoreA
            // 
            this.lblValoreA.AutoSize = true;
            this.lblValoreA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValoreA.ForeColor = System.Drawing.Color.MediumOrchid;
            this.lblValoreA.Location = new System.Drawing.Point(296, 92);
            this.lblValoreA.Name = "lblValoreA";
            this.lblValoreA.Size = new System.Drawing.Size(67, 16);
            this.lblValoreA.TabIndex = 30;
            this.lblValoreA.Text = "Valore A";
            // 
            // cmbSceltaFigura
            // 
            this.cmbSceltaFigura.FormattingEnabled = true;
            this.cmbSceltaFigura.Items.AddRange(new object[] {
            "cubo",
            "sfera"});
            this.cmbSceltaFigura.Location = new System.Drawing.Point(17, 47);
            this.cmbSceltaFigura.Name = "cmbSceltaFigura";
            this.cmbSceltaFigura.Size = new System.Drawing.Size(217, 33);
            this.cmbSceltaFigura.TabIndex = 31;
            this.cmbSceltaFigura.SelectedIndexChanged += new System.EventHandler(this.cmbSceltaFigura_SelectedIndexChanged);
            // 
            // grbSceltaFigura
            // 
            this.grbSceltaFigura.BackColor = System.Drawing.Color.Thistle;
            this.grbSceltaFigura.Controls.Add(this.rdbSuperficie);
            this.grbSceltaFigura.Controls.Add(this.rdbVolume);
            this.grbSceltaFigura.Controls.Add(this.cmbSceltaFigura);
            this.grbSceltaFigura.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSceltaFigura.ForeColor = System.Drawing.Color.Purple;
            this.grbSceltaFigura.Location = new System.Drawing.Point(23, 35);
            this.grbSceltaFigura.Name = "grbSceltaFigura";
            this.grbSceltaFigura.Size = new System.Drawing.Size(253, 284);
            this.grbSceltaFigura.TabIndex = 33;
            this.grbSceltaFigura.TabStop = false;
            this.grbSceltaFigura.Text = "Scelta Figura";
            // 
            // rdbSuperficie
            // 
            this.rdbSuperficie.AutoSize = true;
            this.rdbSuperficie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSuperficie.ForeColor = System.Drawing.Color.MediumOrchid;
            this.rdbSuperficie.Location = new System.Drawing.Point(17, 197);
            this.rdbSuperficie.Name = "rdbSuperficie";
            this.rdbSuperficie.Size = new System.Drawing.Size(154, 24);
            this.rdbSuperficie.TabIndex = 33;
            this.rdbSuperficie.TabStop = true;
            this.rdbSuperficie.Text = "Calcola Superficie";
            this.toolTip2.SetToolTip(this.rdbSuperficie, "Calcola la superficie della figura scelta");
            this.rdbSuperficie.UseVisualStyleBackColor = true;
            this.rdbSuperficie.CheckedChanged += new System.EventHandler(this.rdbSuperficie_CheckedChanged);
            // 
            // rdbVolume
            // 
            this.rdbVolume.AutoSize = true;
            this.rdbVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbVolume.ForeColor = System.Drawing.Color.MediumOrchid;
            this.rdbVolume.Location = new System.Drawing.Point(17, 130);
            this.rdbVolume.Name = "rdbVolume";
            this.rdbVolume.Size = new System.Drawing.Size(137, 24);
            this.rdbVolume.TabIndex = 32;
            this.rdbVolume.TabStop = true;
            this.rdbVolume.Text = "Calcola Volume";
            this.toolTip1.SetToolTip(this.rdbVolume, "Calcola il volume della figura scelta");
            this.rdbVolume.UseVisualStyleBackColor = true;
            this.rdbVolume.CheckedChanged += new System.EventHandler(this.rdbVolume_CheckedChanged);
            // 
            // txtRisultato
            // 
            this.txtRisultato.Location = new System.Drawing.Point(461, 155);
            this.txtRisultato.Multiline = true;
            this.txtRisultato.Name = "txtRisultato";
            this.txtRisultato.Size = new System.Drawing.Size(128, 45);
            this.txtRisultato.TabIndex = 34;
            // 
            // lblOperazione
            // 
            this.lblOperazione.AutoSize = true;
            this.lblOperazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperazione.Location = new System.Drawing.Point(458, 139);
            this.lblOperazione.Name = "lblOperazione";
            this.lblOperazione.Size = new System.Drawing.Size(0, 13);
            this.lblOperazione.TabIndex = 35;
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAzzera.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAzzera.Location = new System.Drawing.Point(285, 264);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(106, 55);
            this.btnAzzera.TabIndex = 36;
            this.btnAzzera.Text = "AZZERA";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // FrmGeometriaSolidaC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(650, 350);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.lblOperazione);
            this.Controls.Add(this.txtRisultato);
            this.Controls.Add(this.grbSceltaFigura);
            this.Controls.Add(this.lblValoreA);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.btnRisultato);
            this.Controls.Add(this.btnChiudi);
            this.Name = "FrmGeometriaSolidaC";
            this.Text = "Geometria Solida Compito";
            this.grbSceltaFigura.ResumeLayout(false);
            this.grbSceltaFigura.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnChiudi;
        private System.Windows.Forms.Button btnRisultato;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lblValoreA;
        private System.Windows.Forms.ComboBox cmbSceltaFigura;
        private System.Windows.Forms.GroupBox grbSceltaFigura;
        private System.Windows.Forms.RadioButton rdbSuperficie;
        private System.Windows.Forms.RadioButton rdbVolume;
        private System.Windows.Forms.TextBox txtRisultato;
        private System.Windows.Forms.Label lblOperazione;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}