﻿namespace primo_form
{
    partial class frmStringhe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grb1 = new System.Windows.Forms.GroupBox();
            this.rdbFinisce = new System.Windows.Forms.RadioButton();
            this.rdbInizia = new System.Windows.Forms.RadioButton();
            this.rdbCarattereIndice = new System.Windows.Forms.RadioButton();
            this.rdbIndiceCarattere = new System.Windows.Forms.RadioButton();
            this.rdbConcatenazione = new System.Windows.Forms.RadioButton();
            this.rdbContiene = new System.Windows.Forms.RadioButton();
            this.rdbMinuscolo = new System.Windows.Forms.RadioButton();
            this.rdbMaiuscolo = new System.Windows.Forms.RadioButton();
            this.rdbLunghezza = new System.Windows.Forms.RadioButton();
            this.lblStringaUno = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lblStringaDue = new System.Windows.Forms.Label();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btnRisultato = new System.Windows.Forms.Button();
            this.txtRisultato = new System.Windows.Forms.TextBox();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip5 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip6 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip7 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip8 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip9 = new System.Windows.Forms.ToolTip(this.components);
            this.grb1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grb1
            // 
            this.grb1.BackColor = System.Drawing.Color.Pink;
            this.grb1.Controls.Add(this.rdbFinisce);
            this.grb1.Controls.Add(this.rdbInizia);
            this.grb1.Controls.Add(this.rdbCarattereIndice);
            this.grb1.Controls.Add(this.rdbIndiceCarattere);
            this.grb1.Controls.Add(this.rdbConcatenazione);
            this.grb1.Controls.Add(this.rdbContiene);
            this.grb1.Controls.Add(this.rdbMinuscolo);
            this.grb1.Controls.Add(this.rdbMaiuscolo);
            this.grb1.Controls.Add(this.rdbLunghezza);
            this.grb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grb1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.grb1.Location = new System.Drawing.Point(29, 34);
            this.grb1.Name = "grb1";
            this.grb1.Size = new System.Drawing.Size(285, 298);
            this.grb1.TabIndex = 2;
            this.grb1.TabStop = false;
            this.grb1.Text = "Scegli l\'operazione";
            // 
            // rdbFinisce
            // 
            this.rdbFinisce.AutoSize = true;
            this.rdbFinisce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbFinisce.Location = new System.Drawing.Point(30, 264);
            this.rdbFinisce.Name = "rdbFinisce";
            this.rdbFinisce.Size = new System.Drawing.Size(64, 19);
            this.rdbFinisce.TabIndex = 8;
            this.rdbFinisce.TabStop = true;
            this.rdbFinisce.Text = "Finisce";
            this.toolTip9.SetToolTip(this.rdbFinisce, "Verifica che la stringa1 finisca con i caratteri della stringa2");
            this.rdbFinisce.UseVisualStyleBackColor = true;
            this.rdbFinisce.CheckedChanged += new System.EventHandler(this.rdbFinisce_CheckedChanged);
            // 
            // rdbInizia
            // 
            this.rdbInizia.AutoSize = true;
            this.rdbInizia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbInizia.Location = new System.Drawing.Point(30, 239);
            this.rdbInizia.Name = "rdbInizia";
            this.rdbInizia.Size = new System.Drawing.Size(54, 19);
            this.rdbInizia.TabIndex = 7;
            this.rdbInizia.TabStop = true;
            this.rdbInizia.Text = "Inizia";
            this.toolTip8.SetToolTip(this.rdbInizia, "Verifica che la stringa1 inizi con i caratteri della stringa2");
            this.rdbInizia.UseVisualStyleBackColor = true;
            this.rdbInizia.CheckedChanged += new System.EventHandler(this.rdbInizia_CheckedChanged);
            // 
            // rdbCarattereIndice
            // 
            this.rdbCarattereIndice.AutoSize = true;
            this.rdbCarattereIndice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCarattereIndice.Location = new System.Drawing.Point(30, 214);
            this.rdbCarattereIndice.Name = "rdbCarattereIndice";
            this.rdbCarattereIndice.Size = new System.Drawing.Size(134, 19);
            this.rdbCarattereIndice.TabIndex = 6;
            this.rdbCarattereIndice.TabStop = true;
            this.rdbCarattereIndice.Text = "Carattere dell\'indice";
            this.toolTip7.SetToolTip(this.rdbCarattereIndice, "Restituisce restituisce il carattere della prima stringa corrispondente alla stri" +
        "nga 2");
            this.rdbCarattereIndice.UseVisualStyleBackColor = true;
            this.rdbCarattereIndice.CheckedChanged += new System.EventHandler(this.rdbCarattereIndice_CheckedChanged);
            // 
            // rdbIndiceCarattere
            // 
            this.rdbIndiceCarattere.AutoSize = true;
            this.rdbIndiceCarattere.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbIndiceCarattere.Location = new System.Drawing.Point(30, 189);
            this.rdbIndiceCarattere.Name = "rdbIndiceCarattere";
            this.rdbIndiceCarattere.Size = new System.Drawing.Size(129, 19);
            this.rdbIndiceCarattere.TabIndex = 5;
            this.rdbIndiceCarattere.TabStop = true;
            this.rdbIndiceCarattere.Text = "Indice del carattere";
            this.toolTip6.SetToolTip(this.rdbIndiceCarattere, "Restituisce la posizione (l\'indice) del carattere inserito nella seconda stringa");
            this.rdbIndiceCarattere.UseVisualStyleBackColor = true;
            this.rdbIndiceCarattere.CheckedChanged += new System.EventHandler(this.rdbIndiceCarattere_CheckedChanged);
            // 
            // rdbConcatenazione
            // 
            this.rdbConcatenazione.AutoSize = true;
            this.rdbConcatenazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbConcatenazione.Location = new System.Drawing.Point(30, 164);
            this.rdbConcatenazione.Name = "rdbConcatenazione";
            this.rdbConcatenazione.Size = new System.Drawing.Size(114, 19);
            this.rdbConcatenazione.TabIndex = 4;
            this.rdbConcatenazione.TabStop = true;
            this.rdbConcatenazione.Text = "Concatenazione";
            this.toolTip5.SetToolTip(this.rdbConcatenazione, "Esegue la concatenazione delle due stringhe");
            this.rdbConcatenazione.UseVisualStyleBackColor = true;
            this.rdbConcatenazione.CheckedChanged += new System.EventHandler(this.rdbConcatenazione_CheckedChanged);
            // 
            // rdbContiene
            // 
            this.rdbContiene.AutoSize = true;
            this.rdbContiene.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbContiene.Location = new System.Drawing.Point(30, 139);
            this.rdbContiene.Name = "rdbContiene";
            this.rdbContiene.Size = new System.Drawing.Size(74, 19);
            this.rdbContiene.TabIndex = 3;
            this.rdbContiene.TabStop = true;
            this.rdbContiene.Text = "Contiene";
            this.toolTip4.SetToolTip(this.rdbContiene, "Verifica se la stringa1 contiene la stringa 2");
            this.rdbContiene.UseVisualStyleBackColor = true;
            this.rdbContiene.CheckedChanged += new System.EventHandler(this.rdbContiene_CheckedChanged);
            // 
            // rdbMinuscolo
            // 
            this.rdbMinuscolo.AutoSize = true;
            this.rdbMinuscolo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbMinuscolo.Location = new System.Drawing.Point(30, 85);
            this.rdbMinuscolo.Name = "rdbMinuscolo";
            this.rdbMinuscolo.Size = new System.Drawing.Size(82, 19);
            this.rdbMinuscolo.TabIndex = 2;
            this.rdbMinuscolo.TabStop = true;
            this.rdbMinuscolo.Text = "Minuscolo";
            this.toolTip3.SetToolTip(this.rdbMinuscolo, "Converte tutta la stringa in minuscolo");
            this.rdbMinuscolo.UseVisualStyleBackColor = true;
            this.rdbMinuscolo.CheckedChanged += new System.EventHandler(this.rdbMinuscolo_CheckedChanged);
            // 
            // rdbMaiuscolo
            // 
            this.rdbMaiuscolo.AutoSize = true;
            this.rdbMaiuscolo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbMaiuscolo.Location = new System.Drawing.Point(30, 60);
            this.rdbMaiuscolo.Name = "rdbMaiuscolo";
            this.rdbMaiuscolo.Size = new System.Drawing.Size(82, 19);
            this.rdbMaiuscolo.TabIndex = 1;
            this.rdbMaiuscolo.TabStop = true;
            this.rdbMaiuscolo.Text = "Maiuscolo";
            this.toolTip2.SetToolTip(this.rdbMaiuscolo, "Converte tutta la stringa in maiuscolo");
            this.rdbMaiuscolo.UseVisualStyleBackColor = true;
            this.rdbMaiuscolo.CheckedChanged += new System.EventHandler(this.rdbMaiuscolo_CheckedChanged);
            // 
            // rdbLunghezza
            // 
            this.rdbLunghezza.AutoSize = true;
            this.rdbLunghezza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLunghezza.Location = new System.Drawing.Point(30, 35);
            this.rdbLunghezza.Name = "rdbLunghezza";
            this.rdbLunghezza.Size = new System.Drawing.Size(86, 19);
            this.rdbLunghezza.TabIndex = 0;
            this.rdbLunghezza.TabStop = true;
            this.rdbLunghezza.Text = "Lunghezza";
            this.toolTip1.SetToolTip(this.rdbLunghezza, "Restituisce la lunghezza della stringa");
            this.rdbLunghezza.UseVisualStyleBackColor = true;
            this.rdbLunghezza.CheckedChanged += new System.EventHandler(this.rdbLunghezza_CheckedChanged);
            // 
            // lblStringaUno
            // 
            this.lblStringaUno.AutoSize = true;
            this.lblStringaUno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStringaUno.ForeColor = System.Drawing.Color.LightPink;
            this.lblStringaUno.Location = new System.Drawing.Point(504, 34);
            this.lblStringaUno.Name = "lblStringaUno";
            this.lblStringaUno.Size = new System.Drawing.Size(68, 16);
            this.lblStringaUno.TabIndex = 31;
            this.lblStringaUno.Text = "Stringa 1";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(507, 54);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(265, 34);
            this.txt1.TabIndex = 32;
            // 
            // lblStringaDue
            // 
            this.lblStringaDue.AutoSize = true;
            this.lblStringaDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStringaDue.ForeColor = System.Drawing.Color.LightPink;
            this.lblStringaDue.Location = new System.Drawing.Point(504, 119);
            this.lblStringaDue.Name = "lblStringaDue";
            this.lblStringaDue.Size = new System.Drawing.Size(68, 16);
            this.lblStringaDue.TabIndex = 33;
            this.lblStringaDue.Text = "Stringa 2";
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(507, 138);
            this.txt2.Multiline = true;
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(265, 34);
            this.txt2.TabIndex = 34;
            // 
            // btnRisultato
            // 
            this.btnRisultato.BackColor = System.Drawing.Color.Pink;
            this.btnRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRisultato.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnRisultato.Location = new System.Drawing.Point(590, 185);
            this.btnRisultato.Name = "btnRisultato";
            this.btnRisultato.Size = new System.Drawing.Size(113, 45);
            this.btnRisultato.TabIndex = 35;
            this.btnRisultato.Text = "Calcola";
            this.btnRisultato.UseVisualStyleBackColor = false;
            this.btnRisultato.Click += new System.EventHandler(this.btnRisultato_Click);
            // 
            // txtRisultato
            // 
            this.txtRisultato.Location = new System.Drawing.Point(510, 236);
            this.txtRisultato.Multiline = true;
            this.txtRisultato.Name = "txtRisultato";
            this.txtRisultato.Size = new System.Drawing.Size(265, 34);
            this.txtRisultato.TabIndex = 36;
            // 
            // btnChiudi
            // 
            this.btnChiudi.BackColor = System.Drawing.Color.Pink;
            this.btnChiudi.Font = new System.Drawing.Font("Papyrus", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiudi.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnChiudi.Location = new System.Drawing.Point(609, 288);
            this.btnChiudi.Name = "btnChiudi";
            this.btnChiudi.Size = new System.Drawing.Size(166, 45);
            this.btnChiudi.TabIndex = 37;
            this.btnChiudi.Text = "<--- CHIUDI E RITORNA";
            this.btnChiudi.UseVisualStyleBackColor = false;
            this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAzzera.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAzzera.Location = new System.Drawing.Point(363, 288);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(106, 45);
            this.btnAzzera.TabIndex = 38;
            this.btnAzzera.Text = "AZZERA";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // frmStringhe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(798, 370);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.btnChiudi);
            this.Controls.Add(this.txtRisultato);
            this.Controls.Add(this.btnRisultato);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.lblStringaDue);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lblStringaUno);
            this.Controls.Add(this.grb1);
            this.Name = "frmStringhe";
            this.Text = "frmStringhe";
            this.grb1.ResumeLayout(false);
            this.grb1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grb1;
        private System.Windows.Forms.RadioButton rdbLunghezza;
        private System.Windows.Forms.RadioButton rdbFinisce;
        private System.Windows.Forms.RadioButton rdbInizia;
        private System.Windows.Forms.RadioButton rdbCarattereIndice;
        private System.Windows.Forms.RadioButton rdbIndiceCarattere;
        private System.Windows.Forms.RadioButton rdbConcatenazione;
        private System.Windows.Forms.RadioButton rdbContiene;
        private System.Windows.Forms.RadioButton rdbMinuscolo;
        private System.Windows.Forms.RadioButton rdbMaiuscolo;
        private System.Windows.Forms.Label lblStringaUno;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lblStringaDue;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button btnRisultato;
        private System.Windows.Forms.TextBox txtRisultato;
        private System.Windows.Forms.Button btnChiudi;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip9;
        private System.Windows.Forms.ToolTip toolTip8;
        private System.Windows.Forms.ToolTip toolTip7;
        private System.Windows.Forms.ToolTip toolTip6;
        private System.Windows.Forms.ToolTip toolTip5;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.ToolTip toolTip3;
    }
}