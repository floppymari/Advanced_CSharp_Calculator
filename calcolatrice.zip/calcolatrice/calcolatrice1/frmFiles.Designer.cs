﻿namespace primo_form
{
    partial class frmFiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.lblCognome = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.lblNumeroTelefono = new System.Windows.Forms.Label();
            this.btnImportaDati = new System.Windows.Forms.Button();
            this.btnEsploraDati = new System.Windows.Forms.Button();
            this.btnModificaDati = new System.Windows.Forms.Button();
            this.btnSalvaDati = new System.Windows.Forms.Button();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.lv1 = new System.Windows.Forms.ListView();
            this.chNome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chCognome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chNumeroTelefono = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnAggiungiDati = new System.Windows.Forms.Button();
            this.btnEliminaDati = new System.Windows.Forms.Button();
            this.btnReload = new System.Windows.Forms.Button();
            this.btnAppendiDati = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(12, 168);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(265, 34);
            this.txt1.TabIndex = 34;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.ForeColor = System.Drawing.Color.LightPink;
            this.lblNome.Location = new System.Drawing.Point(9, 148);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(48, 16);
            this.lblNome.TabIndex = 33;
            this.lblNome.Text = "Nome";
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(12, 236);
            this.txt2.Multiline = true;
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(265, 34);
            this.txt2.TabIndex = 36;
            // 
            // lblCognome
            // 
            this.lblCognome.AutoSize = true;
            this.lblCognome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCognome.ForeColor = System.Drawing.Color.LightPink;
            this.lblCognome.Location = new System.Drawing.Point(9, 216);
            this.lblCognome.Name = "lblCognome";
            this.lblCognome.Size = new System.Drawing.Size(73, 16);
            this.lblCognome.TabIndex = 35;
            this.lblCognome.Text = "Cognome";
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(12, 305);
            this.txt3.Multiline = true;
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(265, 34);
            this.txt3.TabIndex = 38;
            // 
            // lblNumeroTelefono
            // 
            this.lblNumeroTelefono.AutoSize = true;
            this.lblNumeroTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroTelefono.ForeColor = System.Drawing.Color.LightPink;
            this.lblNumeroTelefono.Location = new System.Drawing.Point(9, 286);
            this.lblNumeroTelefono.Name = "lblNumeroTelefono";
            this.lblNumeroTelefono.Size = new System.Drawing.Size(138, 16);
            this.lblNumeroTelefono.TabIndex = 37;
            this.lblNumeroTelefono.Text = "Numero di telefono";
            // 
            // btnImportaDati
            // 
            this.btnImportaDati.BackColor = System.Drawing.Color.Pink;
            this.btnImportaDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportaDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnImportaDati.Location = new System.Drawing.Point(458, 148);
            this.btnImportaDati.Name = "btnImportaDati";
            this.btnImportaDati.Size = new System.Drawing.Size(109, 31);
            this.btnImportaDati.TabIndex = 39;
            this.btnImportaDati.Text = "Importa Dati";
            this.btnImportaDati.UseVisualStyleBackColor = false;
            this.btnImportaDati.Click += new System.EventHandler(this.btnImportaDati_Click);
            // 
            // btnEsploraDati
            // 
            this.btnEsploraDati.BackColor = System.Drawing.Color.Pink;
            this.btnEsploraDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEsploraDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnEsploraDati.Location = new System.Drawing.Point(575, 148);
            this.btnEsploraDati.Name = "btnEsploraDati";
            this.btnEsploraDati.Size = new System.Drawing.Size(109, 31);
            this.btnEsploraDati.TabIndex = 40;
            this.btnEsploraDati.Text = "Esporta Dati";
            this.btnEsploraDati.UseVisualStyleBackColor = false;
            this.btnEsploraDati.Click += new System.EventHandler(this.btnEsploraDati_Click);
            // 
            // btnModificaDati
            // 
            this.btnModificaDati.BackColor = System.Drawing.Color.Pink;
            this.btnModificaDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificaDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnModificaDati.Location = new System.Drawing.Point(693, 148);
            this.btnModificaDati.Name = "btnModificaDati";
            this.btnModificaDati.Size = new System.Drawing.Size(109, 31);
            this.btnModificaDati.TabIndex = 41;
            this.btnModificaDati.Text = "Modifica Dati";
            this.btnModificaDati.UseVisualStyleBackColor = false;
            this.btnModificaDati.Click += new System.EventHandler(this.btnModificaDati_Click);
            // 
            // btnSalvaDati
            // 
            this.btnSalvaDati.BackColor = System.Drawing.Color.Pink;
            this.btnSalvaDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvaDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnSalvaDati.Location = new System.Drawing.Point(575, 185);
            this.btnSalvaDati.Name = "btnSalvaDati";
            this.btnSalvaDati.Size = new System.Drawing.Size(109, 31);
            this.btnSalvaDati.TabIndex = 42;
            this.btnSalvaDati.Text = "Salva Dati";
            this.btnSalvaDati.UseVisualStyleBackColor = false;
            this.btnSalvaDati.Click += new System.EventHandler(this.btnSalvaDati_Click);
            // 
            // btnChiudi
            // 
            this.btnChiudi.BackColor = System.Drawing.Color.Pink;
            this.btnChiudi.Font = new System.Drawing.Font("Papyrus", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiudi.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnChiudi.Location = new System.Drawing.Point(539, 286);
            this.btnChiudi.Name = "btnChiudi";
            this.btnChiudi.Size = new System.Drawing.Size(174, 45);
            this.btnChiudi.TabIndex = 43;
            this.btnChiudi.Text = "<--- CHIUDI E RITORNA";
            this.btnChiudi.UseVisualStyleBackColor = false;
            this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
            // 
            // lv1
            // 
            this.lv1.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lv1.BackColor = System.Drawing.SystemColors.Window;
            this.lv1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chNome,
            this.chCognome,
            this.chNumeroTelefono});
            this.lv1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.lv1.GridLines = true;
            this.lv1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv1.HideSelection = false;
            this.lv1.Location = new System.Drawing.Point(94, 12);
            this.lv1.MultiSelect = false;
            this.lv1.Name = "lv1";
            this.lv1.Size = new System.Drawing.Size(609, 97);
            this.lv1.TabIndex = 19;
            this.lv1.UseCompatibleStateImageBehavior = false;
            this.lv1.View = System.Windows.Forms.View.Details;
            this.lv1.SelectedIndexChanged += new System.EventHandler(this.lv1_SelectedIndexChanged);
            // 
            // chNome
            // 
            this.chNome.Tag = "Nome";
            this.chNome.Text = "Nome";
            this.chNome.Width = 180;
            // 
            // chCognome
            // 
            this.chCognome.Tag = "Cognome";
            this.chCognome.Text = "Cognome";
            this.chCognome.Width = 200;
            // 
            // chNumeroTelefono
            // 
            this.chNumeroTelefono.Tag = "Numero di telefono";
            this.chNumeroTelefono.Text = "Numero di telefono";
            this.chNumeroTelefono.Width = 224;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // btnAggiungiDati
            // 
            this.btnAggiungiDati.BackColor = System.Drawing.Color.Pink;
            this.btnAggiungiDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAggiungiDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnAggiungiDati.Location = new System.Drawing.Point(693, 185);
            this.btnAggiungiDati.Name = "btnAggiungiDati";
            this.btnAggiungiDati.Size = new System.Drawing.Size(109, 31);
            this.btnAggiungiDati.TabIndex = 44;
            this.btnAggiungiDati.Text = "Aggiungi Dati";
            this.btnAggiungiDati.UseVisualStyleBackColor = false;
            this.btnAggiungiDati.Click += new System.EventHandler(this.btnAggiungiDati_Click);
            // 
            // btnEliminaDati
            // 
            this.btnEliminaDati.BackColor = System.Drawing.Color.Pink;
            this.btnEliminaDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminaDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnEliminaDati.Location = new System.Drawing.Point(460, 185);
            this.btnEliminaDati.Name = "btnEliminaDati";
            this.btnEliminaDati.Size = new System.Drawing.Size(109, 31);
            this.btnEliminaDati.TabIndex = 45;
            this.btnEliminaDati.Text = "Elimina Dati";
            this.btnEliminaDati.UseVisualStyleBackColor = false;
            this.btnEliminaDati.Click += new System.EventHandler(this.btnEliminaDati_Click);
            // 
            // btnReload
            // 
            this.btnReload.BackColor = System.Drawing.Color.Pink;
            this.btnReload.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReload.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnReload.Location = new System.Drawing.Point(721, 34);
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(77, 55);
            this.btnReload.TabIndex = 46;
            this.btnReload.Text = "Reload";
            this.btnReload.UseVisualStyleBackColor = false;
            // 
            // btnAppendiDati
            // 
            this.btnAppendiDati.BackColor = System.Drawing.Color.Pink;
            this.btnAppendiDati.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppendiDati.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnAppendiDati.Location = new System.Drawing.Point(575, 222);
            this.btnAppendiDati.Name = "btnAppendiDati";
            this.btnAppendiDati.Size = new System.Drawing.Size(109, 31);
            this.btnAppendiDati.TabIndex = 47;
            this.btnAppendiDati.Text = "Appendi Dati";
            this.btnAppendiDati.UseVisualStyleBackColor = false;
            this.btnAppendiDati.Click += new System.EventHandler(this.btnAppendiDati_Click);
            // 
            // frmFiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(814, 360);
            this.Controls.Add(this.btnAppendiDati);
            this.Controls.Add(this.btnReload);
            this.Controls.Add(this.btnEliminaDati);
            this.Controls.Add(this.btnAggiungiDati);
            this.Controls.Add(this.lv1);
            this.Controls.Add(this.btnChiudi);
            this.Controls.Add(this.btnSalvaDati);
            this.Controls.Add(this.btnModificaDati);
            this.Controls.Add(this.btnEsploraDati);
            this.Controls.Add(this.btnImportaDati);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.lblNumeroTelefono);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.lblCognome);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lblNome);
            this.Name = "frmFiles";
            this.Text = "frmFiles";
            this.Load += new System.EventHandler(this.frmFiles_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Label lblCognome;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Label lblNumeroTelefono;
        private System.Windows.Forms.Button btnImportaDati;
        private System.Windows.Forms.Button btnEsploraDati;
        private System.Windows.Forms.Button btnModificaDati;
        private System.Windows.Forms.Button btnSalvaDati;
        private System.Windows.Forms.Button btnChiudi;
        private System.Windows.Forms.ListView lv1;
        private System.Windows.Forms.ColumnHeader chNome;
        private System.Windows.Forms.ColumnHeader chCognome;
        private System.Windows.Forms.ColumnHeader chNumeroTelefono;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnAggiungiDati;
        private System.Windows.Forms.Button btnEliminaDati;
        private System.Windows.Forms.Button btnReload;
        private System.Windows.Forms.Button btnAppendiDati;
    }
}