﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace primo_form
{
    public partial class frmFiles : Form
    {
        public frmFiles()
        {
            InitializeComponent();
        }
        private void frmFiles_Load(object sender, EventArgs e)
        {
            //quando avvio vedo solo il bottone "Importa Dati"
            btnImportaDati.Enabled = true;
            btnEsploraDati.Visible = true;
            btnEsploraDati.Enabled = false;
            btnModificaDati.Visible = false;   
            btnSalvaDati.Visible = false;
            btnAggiungiDati.Visible = false;
            btnEliminaDati.Visible = false;
            btnAppendiDati.Visible = false;
            txt1.Enabled = false;
            txt2.Enabled = false;
            txt3.Enabled = false;
            txt1.Visible = false;
            txt2.Visible = false;
            txt3.Visible = false;
        }

        //bottone chiudi
        private void btnChiudi_Click(object sender, EventArgs e)
        {
            Close();
        }

        //funzioni create
        void InserisciLinea(string nomeU, string cognomeU, string telefonoU)
        {
            ListViewItem itemOperazione; //riga della ListView

            itemOperazione = new ListViewItem();
            itemOperazione.Text = nomeU;
            itemOperazione.SubItems.Add(cognomeU);
            itemOperazione.SubItems.Add(telefonoU);

            lv1.Items.Add(itemOperazione);
        }
        void LeggiEInserisci(string stringaLinea)
        {
            string[] datiUtente; //1* cosa, dichiaro un array di stringhe, dentro ci metto cosa c'è dentro al file utenti
            datiUtente = stringaLinea.Split(',');
            InserisciLinea(datiUtente[0], datiUtente[1], datiUtente[2]);
        }
        void EliminaLinea(string nomeU, string cognomeU, string telefonoU)
        {
            lv1.FocusedItem.SubItems[0].Text = "";
            lv1.FocusedItem.SubItems[1].Text = "";
            lv1.FocusedItem.SubItems[2].Text = "";
        }

        //button in ordine
        private void btnImportaDati_Click(object sender, EventArgs e)
        {
            openFileDialog1 = new OpenFileDialog(); //per aprire i file

            if (openFileDialog1.ShowDialog() == DialogResult.OK )
            {
                StreamReader sr = new StreamReader(openFileDialog1.FileName); //per farlo funzionare serve aggiungere uma libreria in alto : using System.IO;
                string line; //creo una variabile string

                while ((line = sr.ReadLine()) != null)
                {
                    LeggiEInserisci(line);
                }

                btnModificaDati.Visible = true;
                sr.Close(); //mi chiude il file"utenti"
            }
        }

        private void lv1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lv1.FocusedItem != null)
            {
                txt1.Visible = true;
                txt2.Visible = true;
                txt3.Visible = true;
                txt1.Text = lv1.FocusedItem.Text; //SubItems[0].
                txt2.Text = lv1.FocusedItem.SubItems[1].Text;
                txt3.Text = lv1.FocusedItem.SubItems[2].Text;
            }
        }

        private void btnModificaDati_Click(object sender, EventArgs e)
        {
            txt1.Enabled = true;
            txt2.Enabled = true;
            txt3.Enabled = true;
            txt1.Visible = true;
            txt2.Visible = true;
            txt3.Visible = true;
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
            btnSalvaDati.Visible = true;
            btnAggiungiDati.Visible=true;
            btnEliminaDati.Visible = true;
            btnAppendiDati.Visible = true;
        }

        private void btnSalvaDati_Click(object sender, EventArgs e)
        {
            if (lv1.FocusedItem != null)
            {
                lv1.FocusedItem.Text = txt1.Text;
                lv1.FocusedItem.SubItems[1].Text = txt2.Text;
                lv1.FocusedItem.SubItems[2].Text = txt3.Text;

                btnSalvaDati.Enabled = false;
                btnEsploraDati.Enabled = true;
            }
        }

        private void btnEsploraDati_Click(object sender, EventArgs e)
        {
            openFileDialog1 = new OpenFileDialog(); //per aprire i file

            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(openFileDialog1.FileName);

                string line;

                for (int i = 0; i < lv1.Items.Count; i++)
                {
                    line = lv1.Items[i].Text + ", "
                    + lv1.Items[i].SubItems[1].Text + ", "
                    + lv1.Items[i].SubItems[2].Text;

                    sw.WriteLine(line);

                    if (line != ", , ") //se la riga e' vuota non la esporta
                    {
                        sw.WriteLine(line);
                    }
                }
            }
        }

        private void btnAggiungiDati_Click(object sender, EventArgs e)
        {
            InserisciLinea(txt1.Text, txt2.Text, txt3.Text);
            btnEsploraDati.Enabled = true;
        }

        private void btnEliminaDati_Click(object sender, EventArgs e)
        {
            EliminaLinea(txt1.Text, txt2.Text, txt3.Text);

            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
        }

        private void btnAppendiDati_Click(object sender, EventArgs e)
        {
            openFileDialog1 = new OpenFileDialog(); //per aprire i file

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(openFileDialog1.FileName, true);

                string line;

                for (int i = 0; i < lv1.FocusedItem.Index; i++)
                {
                    line = lv1.Items[i].Text + ", "
                    + lv1.Items[i].SubItems[1].Text + ", "
                    + lv1.Items[i].SubItems[2].Text;

                    sw.WriteLine(line);
                }
            }
        }
    }
}
