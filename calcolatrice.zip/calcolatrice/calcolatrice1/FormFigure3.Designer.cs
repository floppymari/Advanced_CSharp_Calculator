﻿namespace primo_form
{
    partial class FormFigure3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAZZERA = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.txtRisultato = new System.Windows.Forms.TextBox();
            this.lblOperazione = new System.Windows.Forms.Label();
            this.btnRisultato = new System.Windows.Forms.Button();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.grbGeometriaSolida = new System.Windows.Forms.GroupBox();
            this.rdbCercPer = new System.Windows.Forms.RadioButton();
            this.rdbTriPer = new System.Windows.Forms.RadioButton();
            this.rdbRettPer = new System.Windows.Forms.RadioButton();
            this.rdbQuadPer = new System.Windows.Forms.RadioButton();
            this.lblElli = new System.Windows.Forms.Label();
            this.lblPoli = new System.Windows.Forms.Label();
            this.rdbCercAr = new System.Windows.Forms.RadioButton();
            this.rdbTriAr = new System.Windows.Forms.RadioButton();
            this.rdbRettAr = new System.Windows.Forms.RadioButton();
            this.rdbQuadAr = new System.Windows.Forms.RadioButton();
            this.grbGeometriaSolida.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAZZERA
            // 
            this.lblAZZERA.AutoSize = true;
            this.lblAZZERA.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAZZERA.Location = new System.Drawing.Point(308, 235);
            this.lblAZZERA.Name = "lblAZZERA";
            this.lblAZZERA.Size = new System.Drawing.Size(94, 9);
            this.lblAZZERA.TabIndex = 44;
            this.lblAZZERA.Text = "CLICCARE 2 VOLTE";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbl3.Location = new System.Drawing.Point(47, 157);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(73, 18);
            this.lbl3.TabIndex = 43;
            this.lbl3.Text = "Valore C";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbl2.Location = new System.Drawing.Point(48, 103);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(72, 18);
            this.lbl2.TabIndex = 42;
            this.lbl2.Text = "Valore B";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbl1.Location = new System.Drawing.Point(47, 44);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(71, 18);
            this.lbl1.TabIndex = 41;
            this.lbl1.Text = "Valore A";
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(50, 177);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(136, 20);
            this.txt3.TabIndex = 40;
            // 
            // btnChiudi
            // 
            this.btnChiudi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnChiudi.Font = new System.Drawing.Font("Papyrus", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiudi.ForeColor = System.Drawing.Color.ForestGreen;
            this.btnChiudi.Location = new System.Drawing.Point(12, 250);
            this.btnChiudi.Name = "btnChiudi";
            this.btnChiudi.Size = new System.Drawing.Size(211, 42);
            this.btnChiudi.TabIndex = 39;
            this.btnChiudi.Text = "<--- CHIUDI E RITORNA";
            this.btnChiudi.UseVisualStyleBackColor = false;
            this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAzzera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAzzera.Location = new System.Drawing.Point(310, 243);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(92, 53);
            this.btnAzzera.TabIndex = 38;
            this.btnAzzera.Text = "AZZERA";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // txtRisultato
            // 
            this.txtRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRisultato.Location = new System.Drawing.Point(310, 106);
            this.txtRisultato.Multiline = true;
            this.txtRisultato.Name = "txtRisultato";
            this.txtRisultato.Size = new System.Drawing.Size(166, 69);
            this.txtRisultato.TabIndex = 37;
            // 
            // lblOperazione
            // 
            this.lblOperazione.AutoSize = true;
            this.lblOperazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperazione.Location = new System.Drawing.Point(38, 263);
            this.lblOperazione.Name = "lblOperazione";
            this.lblOperazione.Size = new System.Drawing.Size(0, 13);
            this.lblOperazione.TabIndex = 36;
            // 
            // btnRisultato
            // 
            this.btnRisultato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRisultato.ForeColor = System.Drawing.Color.ForestGreen;
            this.btnRisultato.Location = new System.Drawing.Point(212, 117);
            this.btnRisultato.Name = "btnRisultato";
            this.btnRisultato.Size = new System.Drawing.Size(89, 42);
            this.btnRisultato.TabIndex = 35;
            this.btnRisultato.Text = "=";
            this.btnRisultato.UseVisualStyleBackColor = false;
            this.btnRisultato.Click += new System.EventHandler(this.btnRisultato_Click);
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(52, 124);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(136, 20);
            this.txt2.TabIndex = 34;
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(52, 65);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(136, 20);
            this.txt1.TabIndex = 33;
            // 
            // grbGeometriaSolida
            // 
            this.grbGeometriaSolida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.grbGeometriaSolida.Controls.Add(this.rdbCercPer);
            this.grbGeometriaSolida.Controls.Add(this.rdbTriPer);
            this.grbGeometriaSolida.Controls.Add(this.rdbRettPer);
            this.grbGeometriaSolida.Controls.Add(this.rdbQuadPer);
            this.grbGeometriaSolida.Controls.Add(this.lblElli);
            this.grbGeometriaSolida.Controls.Add(this.lblPoli);
            this.grbGeometriaSolida.Controls.Add(this.rdbCercAr);
            this.grbGeometriaSolida.Controls.Add(this.rdbTriAr);
            this.grbGeometriaSolida.Controls.Add(this.rdbRettAr);
            this.grbGeometriaSolida.Controls.Add(this.rdbQuadAr);
            this.grbGeometriaSolida.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbGeometriaSolida.ForeColor = System.Drawing.Color.DarkGreen;
            this.grbGeometriaSolida.Location = new System.Drawing.Point(502, 12);
            this.grbGeometriaSolida.Name = "grbGeometriaSolida";
            this.grbGeometriaSolida.Size = new System.Drawing.Size(306, 281);
            this.grbGeometriaSolida.TabIndex = 32;
            this.grbGeometriaSolida.TabStop = false;
            this.grbGeometriaSolida.Text = "Scegli la figura";
            // 
            // rdbCercPer
            // 
            this.rdbCercPer.AutoSize = true;
            this.rdbCercPer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCercPer.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbCercPer.Location = new System.Drawing.Point(144, 217);
            this.rdbCercPer.Name = "rdbCercPer";
            this.rdbCercPer.Size = new System.Drawing.Size(145, 17);
            this.rdbCercPer.TabIndex = 13;
            this.rdbCercPer.TabStop = true;
            this.rdbCercPer.Text = "Cerchio PERIMETRO";
            this.rdbCercPer.UseVisualStyleBackColor = true;
            this.rdbCercPer.CheckedChanged += new System.EventHandler(this.rdbCercPer_CheckedChanged);
            // 
            // rdbTriPer
            // 
            this.rdbTriPer.AutoSize = true;
            this.rdbTriPer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbTriPer.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbTriPer.Location = new System.Drawing.Point(144, 119);
            this.rdbTriPer.Name = "rdbTriPer";
            this.rdbTriPer.Size = new System.Drawing.Size(155, 17);
            this.rdbTriPer.TabIndex = 12;
            this.rdbTriPer.TabStop = true;
            this.rdbTriPer.Text = "Triangolo PERIMETRO";
            this.rdbTriPer.UseVisualStyleBackColor = true;
            this.rdbTriPer.CheckedChanged += new System.EventHandler(this.rdbTriPer_CheckedChanged);
            // 
            // rdbRettPer
            // 
            this.rdbRettPer.AutoSize = true;
            this.rdbRettPer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbRettPer.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbRettPer.Location = new System.Drawing.Point(144, 93);
            this.rdbRettPer.Name = "rdbRettPer";
            this.rdbRettPer.Size = new System.Drawing.Size(164, 17);
            this.rdbRettPer.TabIndex = 11;
            this.rdbRettPer.TabStop = true;
            this.rdbRettPer.Text = "Rettangolo PERIMETRO";
            this.rdbRettPer.UseVisualStyleBackColor = true;
            this.rdbRettPer.CheckedChanged += new System.EventHandler(this.rdbRettPer_CheckedChanged);
            // 
            // rdbQuadPer
            // 
            this.rdbQuadPer.AutoSize = true;
            this.rdbQuadPer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbQuadPer.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbQuadPer.Location = new System.Drawing.Point(144, 70);
            this.rdbQuadPer.Name = "rdbQuadPer";
            this.rdbQuadPer.Size = new System.Drawing.Size(154, 17);
            this.rdbQuadPer.TabIndex = 10;
            this.rdbQuadPer.TabStop = true;
            this.rdbQuadPer.Text = "Quadrato PERIMETRO";
            this.rdbQuadPer.UseVisualStyleBackColor = true;
            this.rdbQuadPer.CheckedChanged += new System.EventHandler(this.rdbQuadPer_CheckedChanged);
            // 
            // lblElli
            // 
            this.lblElli.AutoSize = true;
            this.lblElli.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElli.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblElli.Location = new System.Drawing.Point(101, 181);
            this.lblElli.Name = "lblElli";
            this.lblElli.Size = new System.Drawing.Size(71, 24);
            this.lblElli.TabIndex = 9;
            this.lblElli.Text = "Ellisse";
            // 
            // lblPoli
            // 
            this.lblPoli.AutoSize = true;
            this.lblPoli.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoli.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblPoli.Location = new System.Drawing.Point(98, 32);
            this.lblPoli.Name = "lblPoli";
            this.lblPoli.Size = new System.Drawing.Size(86, 24);
            this.lblPoli.TabIndex = 8;
            this.lblPoli.Text = "Poligoni";
            // 
            // rdbCercAr
            // 
            this.rdbCercAr.AutoSize = true;
            this.rdbCercAr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCercAr.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbCercAr.Location = new System.Drawing.Point(14, 217);
            this.rdbCercAr.Name = "rdbCercAr";
            this.rdbCercAr.Size = new System.Drawing.Size(105, 17);
            this.rdbCercAr.TabIndex = 5;
            this.rdbCercAr.TabStop = true;
            this.rdbCercAr.Text = "Cerchio AREA";
            this.rdbCercAr.UseVisualStyleBackColor = true;
            this.rdbCercAr.CheckedChanged += new System.EventHandler(this.rdbCercAr_CheckedChanged);
            // 
            // rdbTriAr
            // 
            this.rdbTriAr.AutoSize = true;
            this.rdbTriAr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbTriAr.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbTriAr.Location = new System.Drawing.Point(14, 119);
            this.rdbTriAr.Name = "rdbTriAr";
            this.rdbTriAr.Size = new System.Drawing.Size(115, 17);
            this.rdbTriAr.TabIndex = 3;
            this.rdbTriAr.TabStop = true;
            this.rdbTriAr.Text = "Triangolo AREA";
            this.rdbTriAr.UseVisualStyleBackColor = true;
            this.rdbTriAr.CheckedChanged += new System.EventHandler(this.rdbTriAr_CheckedChanged);
            // 
            // rdbRettAr
            // 
            this.rdbRettAr.AutoSize = true;
            this.rdbRettAr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbRettAr.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbRettAr.Location = new System.Drawing.Point(14, 93);
            this.rdbRettAr.Name = "rdbRettAr";
            this.rdbRettAr.Size = new System.Drawing.Size(124, 17);
            this.rdbRettAr.TabIndex = 2;
            this.rdbRettAr.TabStop = true;
            this.rdbRettAr.Text = "Rettangolo AREA";
            this.rdbRettAr.UseVisualStyleBackColor = true;
            this.rdbRettAr.CheckedChanged += new System.EventHandler(this.rdbRettAr_CheckedChanged);
            // 
            // rdbQuadAr
            // 
            this.rdbQuadAr.AutoSize = true;
            this.rdbQuadAr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbQuadAr.ForeColor = System.Drawing.Color.DarkGreen;
            this.rdbQuadAr.Location = new System.Drawing.Point(14, 70);
            this.rdbQuadAr.Name = "rdbQuadAr";
            this.rdbQuadAr.Size = new System.Drawing.Size(114, 17);
            this.rdbQuadAr.TabIndex = 1;
            this.rdbQuadAr.TabStop = true;
            this.rdbQuadAr.Text = "Quadrato AREA";
            this.rdbQuadAr.UseVisualStyleBackColor = true;
            this.rdbQuadAr.CheckedChanged += new System.EventHandler(this.rdbQuadAr_CheckedChanged);
            // 
            // FormFigure3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(811, 310);
            this.Controls.Add(this.lblAZZERA);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.btnChiudi);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.txtRisultato);
            this.Controls.Add(this.lblOperazione);
            this.Controls.Add(this.btnRisultato);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.grbGeometriaSolida);
            this.Name = "FormFigure3";
            this.Text = "FormFigure3";
            this.grbGeometriaSolida.ResumeLayout(false);
            this.grbGeometriaSolida.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAZZERA;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Button btnChiudi;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.TextBox txtRisultato;
        private System.Windows.Forms.Label lblOperazione;
        private System.Windows.Forms.Button btnRisultato;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.GroupBox grbGeometriaSolida;
        private System.Windows.Forms.RadioButton rdbCercAr;
        private System.Windows.Forms.RadioButton rdbTriAr;
        private System.Windows.Forms.RadioButton rdbRettAr;
        private System.Windows.Forms.RadioButton rdbQuadAr;
        private System.Windows.Forms.Label lblPoli;
        private System.Windows.Forms.Label lblElli;
        private System.Windows.Forms.RadioButton rdbTriPer;
        private System.Windows.Forms.RadioButton rdbRettPer;
        private System.Windows.Forms.RadioButton rdbQuadPer;
        private System.Windows.Forms.RadioButton rdbCercPer;
    }
}