﻿namespace primo_form
{
    partial class FrmGeometriaSolida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grbGeometriaSolida = new System.Windows.Forms.GroupBox();
            this.rdbSferaSuperficie = new System.Windows.Forms.RadioButton();
            this.rdbSferaVolume = new System.Windows.Forms.RadioButton();
            this.rdbParallelepipedoSuperficie = new System.Windows.Forms.RadioButton();
            this.rdbParallelepipedoVolume = new System.Windows.Forms.RadioButton();
            this.rdbCilindroSuperficie = new System.Windows.Forms.RadioButton();
            this.rdbCilindroVolume = new System.Windows.Forms.RadioButton();
            this.rdbCuboSuperficie = new System.Windows.Forms.RadioButton();
            this.rdbCuboVolume = new System.Windows.Forms.RadioButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btnRisultato = new System.Windows.Forms.Button();
            this.txtRisultato = new System.Windows.Forms.TextBox();
            this.lblOperazione = new System.Windows.Forms.Label();
            this.btnAzzera = new System.Windows.Forms.Button();
            this.btnChiudi = new System.Windows.Forms.Button();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lblAZZERA = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip5 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip6 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip7 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip8 = new System.Windows.Forms.ToolTip(this.components);
            this.grbGeometriaSolida.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbGeometriaSolida
            // 
            this.grbGeometriaSolida.BackColor = System.Drawing.Color.Pink;
            this.grbGeometriaSolida.Controls.Add(this.rdbSferaSuperficie);
            this.grbGeometriaSolida.Controls.Add(this.rdbSferaVolume);
            this.grbGeometriaSolida.Controls.Add(this.rdbParallelepipedoSuperficie);
            this.grbGeometriaSolida.Controls.Add(this.rdbParallelepipedoVolume);
            this.grbGeometriaSolida.Controls.Add(this.rdbCilindroSuperficie);
            this.grbGeometriaSolida.Controls.Add(this.rdbCilindroVolume);
            this.grbGeometriaSolida.Controls.Add(this.rdbCuboSuperficie);
            this.grbGeometriaSolida.Controls.Add(this.rdbCuboVolume);
            this.grbGeometriaSolida.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbGeometriaSolida.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.grbGeometriaSolida.Location = new System.Drawing.Point(21, 36);
            this.grbGeometriaSolida.Name = "grbGeometriaSolida";
            this.grbGeometriaSolida.Size = new System.Drawing.Size(309, 478);
            this.grbGeometriaSolida.TabIndex = 0;
            this.grbGeometriaSolida.TabStop = false;
            this.grbGeometriaSolida.Text = "Scegli la figura";
            // 
            // rdbSferaSuperficie
            // 
            this.rdbSferaSuperficie.AutoSize = true;
            this.rdbSferaSuperficie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSferaSuperficie.Location = new System.Drawing.Point(28, 423);
            this.rdbSferaSuperficie.Name = "rdbSferaSuperficie";
            this.rdbSferaSuperficie.Size = new System.Drawing.Size(184, 24);
            this.rdbSferaSuperficie.TabIndex = 7;
            this.rdbSferaSuperficie.TabStop = true;
            this.rdbSferaSuperficie.Text = "Sfera SUPERFICIE";
            this.toolTip8.SetToolTip(this.rdbSferaSuperficie, "Calcola il valore della superficie della sfera");
            this.rdbSferaSuperficie.UseVisualStyleBackColor = true;
            this.rdbSferaSuperficie.CheckedChanged += new System.EventHandler(this.rdbSferaSuperficie_CheckedChanged);
            // 
            // rdbSferaVolume
            // 
            this.rdbSferaVolume.AutoSize = true;
            this.rdbSferaVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSferaVolume.Location = new System.Drawing.Point(28, 384);
            this.rdbSferaVolume.Name = "rdbSferaVolume";
            this.rdbSferaVolume.Size = new System.Drawing.Size(150, 24);
            this.rdbSferaVolume.TabIndex = 6;
            this.rdbSferaVolume.TabStop = true;
            this.rdbSferaVolume.Text = "Sfera VOLUME";
            this.toolTip7.SetToolTip(this.rdbSferaVolume, "Calcola il valore del volume della sfera");
            this.rdbSferaVolume.UseVisualStyleBackColor = true;
            this.rdbSferaVolume.CheckedChanged += new System.EventHandler(this.rdbSferaVolume_CheckedChanged);
            // 
            // rdbParallelepipedoSuperficie
            // 
            this.rdbParallelepipedoSuperficie.AutoSize = true;
            this.rdbParallelepipedoSuperficie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbParallelepipedoSuperficie.Location = new System.Drawing.Point(28, 310);
            this.rdbParallelepipedoSuperficie.Name = "rdbParallelepipedoSuperficie";
            this.rdbParallelepipedoSuperficie.Size = new System.Drawing.Size(263, 24);
            this.rdbParallelepipedoSuperficie.TabIndex = 5;
            this.rdbParallelepipedoSuperficie.TabStop = true;
            this.rdbParallelepipedoSuperficie.Text = "Parallelepipedo SUPERFICIE";
            this.toolTip6.SetToolTip(this.rdbParallelepipedoSuperficie, "Calcola il valore della superficie del parallelepipedo");
            this.rdbParallelepipedoSuperficie.UseVisualStyleBackColor = true;
            this.rdbParallelepipedoSuperficie.CheckedChanged += new System.EventHandler(this.rdbParallelepipedoSuperficie_CheckedChanged);
            // 
            // rdbParallelepipedoVolume
            // 
            this.rdbParallelepipedoVolume.AutoSize = true;
            this.rdbParallelepipedoVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbParallelepipedoVolume.Location = new System.Drawing.Point(28, 271);
            this.rdbParallelepipedoVolume.Name = "rdbParallelepipedoVolume";
            this.rdbParallelepipedoVolume.Size = new System.Drawing.Size(229, 24);
            this.rdbParallelepipedoVolume.TabIndex = 4;
            this.rdbParallelepipedoVolume.TabStop = true;
            this.rdbParallelepipedoVolume.Text = "Parallelepipedo VOLUME";
            this.toolTip5.SetToolTip(this.rdbParallelepipedoVolume, "Calcola il valore del volume del parallelepipedo");
            this.rdbParallelepipedoVolume.UseVisualStyleBackColor = true;
            this.rdbParallelepipedoVolume.CheckedChanged += new System.EventHandler(this.rdbParallelepipedoVolume_CheckedChanged);
            // 
            // rdbCilindroSuperficie
            // 
            this.rdbCilindroSuperficie.AutoSize = true;
            this.rdbCilindroSuperficie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCilindroSuperficie.Location = new System.Drawing.Point(28, 200);
            this.rdbCilindroSuperficie.Name = "rdbCilindroSuperficie";
            this.rdbCilindroSuperficie.Size = new System.Drawing.Size(200, 24);
            this.rdbCilindroSuperficie.TabIndex = 3;
            this.rdbCilindroSuperficie.TabStop = true;
            this.rdbCilindroSuperficie.Text = "Cilindro SUPERFICIE";
            this.toolTip4.SetToolTip(this.rdbCilindroSuperficie, "Calcola il valore della superficie del cilindro");
            this.rdbCilindroSuperficie.UseVisualStyleBackColor = true;
            this.rdbCilindroSuperficie.CheckedChanged += new System.EventHandler(this.rdbCilindroSuperficie_CheckedChanged);
            // 
            // rdbCilindroVolume
            // 
            this.rdbCilindroVolume.AutoSize = true;
            this.rdbCilindroVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCilindroVolume.Location = new System.Drawing.Point(28, 161);
            this.rdbCilindroVolume.Name = "rdbCilindroVolume";
            this.rdbCilindroVolume.Size = new System.Drawing.Size(166, 24);
            this.rdbCilindroVolume.TabIndex = 2;
            this.rdbCilindroVolume.TabStop = true;
            this.rdbCilindroVolume.Text = "Cilindro VOLUME";
            this.toolTip3.SetToolTip(this.rdbCilindroVolume, "Calcola il valore del volume del cilindro");
            this.rdbCilindroVolume.UseVisualStyleBackColor = true;
            this.rdbCilindroVolume.CheckedChanged += new System.EventHandler(this.rdbCilindroVolume_CheckedChanged);
            // 
            // rdbCuboSuperficie
            // 
            this.rdbCuboSuperficie.AutoSize = true;
            this.rdbCuboSuperficie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCuboSuperficie.Location = new System.Drawing.Point(28, 89);
            this.rdbCuboSuperficie.Name = "rdbCuboSuperficie";
            this.rdbCuboSuperficie.Size = new System.Drawing.Size(182, 24);
            this.rdbCuboSuperficie.TabIndex = 1;
            this.rdbCuboSuperficie.TabStop = true;
            this.rdbCuboSuperficie.Text = "Cubo SUPERFICIE";
            this.toolTip2.SetToolTip(this.rdbCuboSuperficie, "Calcola il valore della superficie del cubo");
            this.rdbCuboSuperficie.UseVisualStyleBackColor = true;
            this.rdbCuboSuperficie.CheckedChanged += new System.EventHandler(this.rdbCuboSuperficie_CheckedChanged);
            // 
            // rdbCuboVolume
            // 
            this.rdbCuboVolume.AutoSize = true;
            this.rdbCuboVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbCuboVolume.Location = new System.Drawing.Point(28, 50);
            this.rdbCuboVolume.Name = "rdbCuboVolume";
            this.rdbCuboVolume.Size = new System.Drawing.Size(148, 24);
            this.rdbCuboVolume.TabIndex = 0;
            this.rdbCuboVolume.TabStop = true;
            this.rdbCuboVolume.Text = "Cubo VOLUME";
            this.toolTip1.SetToolTip(this.rdbCuboVolume, "Calcola il valore del volume del cubo");
            this.rdbCuboVolume.UseVisualStyleBackColor = true;
            this.rdbCuboVolume.CheckedChanged += new System.EventHandler(this.rdbCuboVolume_CheckedChanged);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(609, 50);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(136, 20);
            this.txt1.TabIndex = 3;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(609, 128);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(136, 20);
            this.txt2.TabIndex = 4;
            // 
            // btnRisultato
            // 
            this.btnRisultato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRisultato.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnRisultato.Location = new System.Drawing.Point(356, 301);
            this.btnRisultato.Name = "btnRisultato";
            this.btnRisultato.Size = new System.Drawing.Size(133, 87);
            this.btnRisultato.TabIndex = 17;
            this.btnRisultato.Text = "=";
            this.btnRisultato.UseVisualStyleBackColor = false;
            this.btnRisultato.Click += new System.EventHandler(this.btnRisultato_Click);
            // 
            // txtRisultato
            // 
            this.txtRisultato.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRisultato.Location = new System.Drawing.Point(577, 317);
            this.txtRisultato.Multiline = true;
            this.txtRisultato.Name = "txtRisultato";
            this.txtRisultato.Size = new System.Drawing.Size(166, 69);
            this.txtRisultato.TabIndex = 24;
            // 
            // lblOperazione
            // 
            this.lblOperazione.AutoSize = true;
            this.lblOperazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperazione.Location = new System.Drawing.Point(574, 301);
            this.lblOperazione.Name = "lblOperazione";
            this.lblOperazione.Size = new System.Drawing.Size(0, 13);
            this.lblOperazione.TabIndex = 23;
            // 
            // btnAzzera
            // 
            this.btnAzzera.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAzzera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAzzera.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btnAzzera.Location = new System.Drawing.Point(376, 450);
            this.btnAzzera.Name = "btnAzzera";
            this.btnAzzera.Size = new System.Drawing.Size(92, 53);
            this.btnAzzera.TabIndex = 25;
            this.btnAzzera.Text = "AZZERA";
            this.btnAzzera.UseVisualStyleBackColor = false;
            this.btnAzzera.Click += new System.EventHandler(this.btnAzzera_Click);
            // 
            // btnChiudi
            // 
            this.btnChiudi.BackColor = System.Drawing.Color.Pink;
            this.btnChiudi.Font = new System.Drawing.Font("Papyrus", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChiudi.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.btnChiudi.Location = new System.Drawing.Point(532, 472);
            this.btnChiudi.Name = "btnChiudi";
            this.btnChiudi.Size = new System.Drawing.Size(211, 42);
            this.btnChiudi.TabIndex = 26;
            this.btnChiudi.Text = "<--- CHIUDI E RITORNA";
            this.btnChiudi.UseVisualStyleBackColor = false;
            this.btnChiudi.Click += new System.EventHandler(this.btnChiudi_Click);
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(609, 203);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(136, 20);
            this.txt3.TabIndex = 27;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.lbl1.Location = new System.Drawing.Point(416, 49);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(71, 18);
            this.lbl1.TabIndex = 28;
            this.lbl1.Text = "Valore A";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.lbl2.Location = new System.Drawing.Point(417, 127);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(72, 18);
            this.lbl2.TabIndex = 29;
            this.lbl2.Text = "Valore B";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.LavenderBlush;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.lbl3.Location = new System.Drawing.Point(416, 202);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(73, 18);
            this.lbl3.TabIndex = 30;
            this.lbl3.Text = "Valore C";
            // 
            // lblAZZERA
            // 
            this.lblAZZERA.AutoSize = true;
            this.lblAZZERA.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAZZERA.Location = new System.Drawing.Point(374, 438);
            this.lblAZZERA.Name = "lblAZZERA";
            this.lblAZZERA.Size = new System.Drawing.Size(94, 9);
            this.lblAZZERA.TabIndex = 31;
            this.lblAZZERA.Text = "CLICCARE 2 VOLTE";
            // 
            // FrmGeometriaSolida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(766, 548);
            this.Controls.Add(this.lblAZZERA);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.btnChiudi);
            this.Controls.Add(this.btnAzzera);
            this.Controls.Add(this.txtRisultato);
            this.Controls.Add(this.lblOperazione);
            this.Controls.Add(this.btnRisultato);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.grbGeometriaSolida);
            this.Name = "FrmGeometriaSolida";
            this.Text = "Geometria Solida";
            this.grbGeometriaSolida.ResumeLayout(false);
            this.grbGeometriaSolida.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbGeometriaSolida;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button btnRisultato;
        private System.Windows.Forms.TextBox txtRisultato;
        private System.Windows.Forms.Label lblOperazione;
        private System.Windows.Forms.Button btnAzzera;
        private System.Windows.Forms.Button btnChiudi;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.RadioButton rdbCuboVolume;
        private System.Windows.Forms.RadioButton rdbParallelepipedoSuperficie;
        private System.Windows.Forms.RadioButton rdbParallelepipedoVolume;
        private System.Windows.Forms.RadioButton rdbCilindroSuperficie;
        private System.Windows.Forms.RadioButton rdbCilindroVolume;
        private System.Windows.Forms.RadioButton rdbCuboSuperficie;
        private System.Windows.Forms.RadioButton rdbSferaSuperficie;
        private System.Windows.Forms.RadioButton rdbSferaVolume;
        private System.Windows.Forms.Label lblAZZERA;
        private System.Windows.Forms.ToolTip toolTip8;
        private System.Windows.Forms.ToolTip toolTip7;
        private System.Windows.Forms.ToolTip toolTip6;
        private System.Windows.Forms.ToolTip toolTip5;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}