﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace primo_form
{
    public partial class frmPrimaFinestra : Form
    {
        public frmPrimaFinestra()
        {
            InitializeComponent();

            //visibilità
            grbBase.Visible = false;
            grbScientifica.Visible = false;
            grbGeometria.Visible = false;
        }

        //dichiarazioni
        double primoNumero = 0;
        double secondoNumero = 0;
        double totale = 0;

        bool somma = false;
        bool sottrazione = false;
        bool moltiplicazione = false;
        bool divisione = false;

        bool radiceQuadrata = false;
        bool potenza = false;
        bool fattoriale = false;
        bool seno = false;
        bool coseno = false;
        bool tangente = false;

        bool rettangolo = false;
        bool quadrato = false;
        bool rombo = false;
        bool parallelogramma = false;
        bool cerchio = false;

        //bottone per azzerare
        private void btnAzzera_Click(object sender, EventArgs e)
        {
            //azzeramento delle variabili numeriche
            primoNumero = 0;
            secondoNumero = 0;
            totale = 0;

            //azzeramento delle TextBox
            textBox.Visible = true;
            textBox3.Visible = true;
            textBox.Text = "";
            textBox3.Text = "";
            txtRisultato.Text = "";

            //reimpostazione delle etichette e risultati
            lblValoreA.Visible = true;
            lblValoreB.Visible = true;
            lblValoreA.Text = "Valore A";
            lblValoreB.Text = "Valore B";
            lblOperazione.Text = "";

            //reimpostazione dei booleani
            somma = false;
            sottrazione = false;
            moltiplicazione = false;
            divisione = false;
            radiceQuadrata = false;
            potenza = false;
            fattoriale = false;
            seno = false;
            coseno = false;
            tangente = false;
            rettangolo = false;
            quadrato = false;
            rombo = false;
            parallelogramma = false;
            cerchio = false;
            chkRadiceQuadrata.Checked = false;
            chkPotenze.Checked = false;
            chkFattoriale.Checked = false;
            chkSeno.Checked = false;
            chkCoseno.Checked = false;
            chkTangente.Checked = false;

            //deselezione dei RadioButton
            cmbSceltaFigura.Text = "";
            rdbArea.Checked = false;
            rdbPerimetro.Checked = false;

            //focalizzare la prima TextBox
            textBox.Focus();
        }

        //verifica se sono troppi checked (ce ne può essere uno solo)
        private int VerificaChecked()
        {
            int nChecked = 0;

            if (chkRadiceQuadrata.Checked) nChecked++;
            if (chkPotenze.Checked) nChecked++;
            if (chkFattoriale.Checked) nChecked++;
            if (chkSeno.Checked) nChecked++;
            if (chkCoseno.Checked) nChecked++;
            if (chkTangente.Checked) nChecked++;

            if (nChecked > 1)
            {
                MessageBox.Show("Puoi scegliere solo un'operazione", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //deseleziona tutte le checkbox e resetta i label
                lblValoreA.Text = "Valore A";
                lblValoreB.Text = "Valore B";
                chkRadiceQuadrata.Checked = false;
                chkPotenze.Checked = false;
                chkFattoriale.Checked = false;
                chkSeno.Checked = false;
                chkCoseno.Checked = false;
                chkTangente.Checked = false;
            }

            return nChecked;
        }

        //button numeri (0 a 9) + isOperazioneDueOperandi
        private bool isOperazioneDueOperandi()
        {
            if ((somma == true) || (sottrazione == true) || (moltiplicazione == true) || (divisione == true))
                return true;
            else
                return false;
        }
        private void bottone1_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
                textBox3.Text = textBox3.Text + "1";
            else
                textBox.Text = textBox.Text + "1";
        }
        private void bottone2_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
                textBox3.Text = textBox3.Text + "2";
            else
                textBox.Text = textBox.Text + "2";
        }
        private void bottone3_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
                textBox3.Text = textBox3.Text + "3";
            else
                textBox.Text = textBox.Text + "3";
        }
        private void bottone4_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
                textBox3.Text = textBox3.Text + "4";
            else
                textBox.Text = textBox.Text + "4";
        }
        private void bottone5_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
                textBox3.Text += "5";
            else
                textBox.Text += "5";
        }
        private void bottone6_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
            {
                textBox3.Text = textBox3.Text + "6";
            }
            else
            {
                textBox.Text = textBox.Text + "6";
            }
        }
        private void bottone7_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
            {
                textBox3.Text = textBox3.Text + "7";
            }
            else
            {
                textBox.Text = textBox.Text + "7";
            }
        }
        private void bottone8_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
            {
                textBox3.Text = textBox3.Text + "8";
            }
            else
            {
                textBox.Text = textBox.Text + "8";
            }
        }
        private void bottone9_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
            {
                textBox3.Text = textBox3.Text + "9";
            }
            else
            {
                textBox.Text = textBox.Text + "9";
            }
        }
        private void bottone0_Click(object sender, EventArgs e)
        {
            if (isOperazioneDueOperandi())
            {
                textBox3.Text = textBox3.Text + "0";
            }
            else
            {
                textBox.Text = textBox.Text + "0";
            }
        }

        //button operazioni
        private void btnSOMMA_Click(object sender, EventArgs e)
        {
            primoNumero = Convert.ToDouble(textBox.Text);
            somma = true;
            lblOperazione.Text = textBox.Text + "+";
            textBox.Text = "";
            textBox3.Focus();
        }
        private void btnSOTTRAZIONE_Click(object sender, EventArgs e)
        {
            primoNumero = Convert.ToDouble(textBox.Text);
            sottrazione = true;
            lblOperazione.Text = textBox.Text + "-";
            textBox.Text = "";
            textBox3.Focus();
        }
        private void btnMOLTIPLICAZIONE_Click(object sender, EventArgs e)
        {
            primoNumero = Convert.ToDouble(textBox.Text);
            moltiplicazione = true;
            lblOperazione.Text = textBox.Text + "*";
            textBox.Text = "";
            textBox3.Focus();
        }
        private void btnDIVISIONE_Click(object sender, EventArgs e)
        {
            primoNumero = Convert.ToDouble(textBox.Text);
            divisione = true;
            lblOperazione.Text = textBox.Text + "/";
            textBox.Text = "";
            textBox3.Focus();
        }

        //funzione per calcolare il fattoriale
        private int CalcolaFattoriale(int num)
        {
            if (num == 0 || num == 1)
                return 1;
            return num * CalcolaFattoriale(num - 1);
        }

        //risultato
        private void btnRISULTATO_Click(object sender, EventArgs e)
        {
            if (textBox.Text != "" && textBox3.Text == "" && isOperazioneDueOperandi())
            {
                MessageBox.Show("Inserire il secondo numero prima di calcolare il risultato", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (textBox3.Text != "")
            {
                secondoNumero = Convert.ToDouble(textBox3.Text);
                lblOperazione.Text += textBox3.Text;

                //operazioni + - * :
                if (somma)
                {
                    totale = primoNumero + secondoNumero;
                    txtRisultato.Text = Convert.ToString(totale);
                    somma = false;
                }
                if (sottrazione)
                {
                    totale = primoNumero - secondoNumero;
                    txtRisultato.Text = Convert.ToString(totale);
                    sottrazione = false;
                }
                if (moltiplicazione)
                {
                    totale = primoNumero * secondoNumero;
                    txtRisultato.Text = Convert.ToString(totale);
                    moltiplicazione = false;
                }
                if (divisione)
                {
                    if (secondoNumero == 0) //se dividi per zero
                    {
                        MessageBox.Show("Errore: divisione per zero", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtRisultato.Text = "Errore";
                    }
                    else
                    {
                        totale = primoNumero / secondoNumero;
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                    divisione = false;
                }

                //operazione della calcolatrice scientifica
                if (potenza)
                {
                    primoNumero = Convert.ToDouble(textBox.Text);
                    totale = Math.Pow(primoNumero, secondoNumero);
                    lblOperazione.Text = Convert.ToString(primoNumero) + "^" + Convert.ToString(secondoNumero);
                    txtRisultato.Text = Convert.ToString(totale);
                    potenza = false;
                }
                textBox3.Focus();

                if (rettangolo)
                {
                    if (rdbArea.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //base
                        secondoNumero = Convert.ToDouble(textBox3.Text); //altezza
                        totale = primoNumero * secondoNumero;
                        lblOperazione.Text = Convert.ToString(primoNumero) + " * " + Convert.ToString(secondoNumero);
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                    if (rdbPerimetro.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text);
                        secondoNumero = Convert.ToDouble(textBox3.Text); 
                        totale = 2 * (primoNumero + secondoNumero);
                        lblOperazione.Text = "2 * (" + Convert.ToString(primoNumero) + " + " + Convert.ToString(secondoNumero) + ")";
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                }

                if (rombo)
                {
                    if (rdbArea.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //diagonale Maggiore
                        secondoNumero = Convert.ToDouble(textBox3.Text); //diagonale Minore
                        totale = (primoNumero * secondoNumero) / 2;
                        lblOperazione.Text = "(" + Convert.ToString(primoNumero) + " * " + Convert.ToString(secondoNumero) + ") / 2";
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                    
                }

                if (parallelogramma)
                {
                    if (rdbArea.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //base
                        secondoNumero = Convert.ToDouble(textBox3.Text); //altezza
                        totale = primoNumero * secondoNumero;
                        lblOperazione.Text = Convert.ToString(primoNumero) + " * " + Convert.ToString(secondoNumero);
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                    if (rdbPerimetro.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //base
                        secondoNumero = Convert.ToDouble(textBox3.Text); //lato Obliquo
                        totale = 2 * (primoNumero + secondoNumero);
                        lblOperazione.Text = "2 * (" + Convert.ToString(primoNumero) + " + " + Convert.ToString(secondoNumero) + ")";
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                }
            }
            else //operazioni con un solo operando
            {
                if (rombo)
                {
                    if (rdbPerimetro.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //lato
                        totale = 4 * primoNumero;
                        lblOperazione.Text = "4 * " + Convert.ToString(primoNumero);
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                }

                if (quadrato)
                {
                    if (rdbArea.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //lato
                        totale = primoNumero * primoNumero;
                        lblOperazione.Text = Convert.ToString(primoNumero) + " * " + Convert.ToString(primoNumero);
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                    if (rdbPerimetro.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text);
                        totale = 4 * primoNumero;
                        lblOperazione.Text = "4 * " + Convert.ToString(primoNumero);
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                }

                if (cerchio)
                {
                    if (rdbArea.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //diametro
                        totale = (Math.PI * primoNumero * primoNumero) / 4;
                        lblOperazione.Text = "(π * " + Convert.ToString(primoNumero) + "^2) / 4";
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                    if (rdbPerimetro.Checked)
                    {
                        primoNumero = Convert.ToDouble(textBox.Text); //diametro
                        totale = Math.PI * primoNumero;
                        lblOperazione.Text = "π * " + Convert.ToString(primoNumero);
                        txtRisultato.Text = Convert.ToString(totale);
                    }
                }

                if (radiceQuadrata)
                {
                    primoNumero = Convert.ToInt32(textBox.Text);
                    totale = Math.Sqrt(primoNumero);
                    lblOperazione.Text = "√" + primoNumero;
                    txtRisultato.Text = Convert.ToString(totale);
                    radiceQuadrata = false;
                }
                textBox3.Focus();
                if (fattoriale)
                {
                    int numerof = Convert.ToInt32(textBox.Text);
                    totale = CalcolaFattoriale(numerof);
                    lblOperazione.Text = numerof + "!";
                    txtRisultato.Text = Convert.ToString(totale);
                    fattoriale = false;
                }
                textBox3.Focus();
                if (seno)
                {
                    primoNumero = Convert.ToInt32(textBox.Text);
                    totale = Math.Sin(primoNumero);
                    lblOperazione.Text = "sin(" + primoNumero + ")";
                    txtRisultato.Text = Convert.ToString(totale);
                    seno = false;
                }
                textBox3.Focus();
                if (coseno)
                {
                    primoNumero = Convert.ToInt32(textBox.Text);
                    totale = Math.Cos(primoNumero);
                    lblOperazione.Text = "cos(" + primoNumero + ")";
                    txtRisultato.Text = Convert.ToString(totale);
                    coseno = false;
                }
                textBox3.Focus();
                if (tangente)
                {
                    primoNumero = Convert.ToInt32(textBox.Text);
                    totale = Math.Tan(primoNumero);
                    lblOperazione.Text = "tan(" + primoNumero + ")";
                    txtRisultato.Text = Convert.ToString(totale);
                    tangente = false;
                }
            }
        }

        //radiobutton base, scientifica e geometrica
        private void rdbBase_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbBase.Checked)
            {
                grbBase.Visible = true;
                grbScientifica.Visible = false;
                grbGeometria.Visible = false;
            }
            else //(rdbScientifica.Checked)
            {
                grbBase.Visible = false;
                grbScientifica.Visible = true;
                grbGeometria.Visible = false;
            }
        }
        private void rdbScientifica_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbScientifica.Checked)
            {
                grbBase.Visible = false;
                grbGeometria.Visible = false;
                grbScientifica.Visible = true;
            }
            else
            {
                grbBase.Visible = true;
                grbGeometria.Visible = false;
                grbScientifica.Visible = false;
            }
        }
        private void rdbEntrambe_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbEntrambe.Checked)
            {
                MessageBox.Show("Puoi visualizzare entrambe le modalita' ma puoi usarne solo una", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
                grbBase.Visible = true;
                grbScientifica.Visible = true;
                grbGeometria.Visible = false;
            }
        }
        private void rdbGeometrica_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbGeometrica.Checked)
            {
                grbBase.Visible = false;
                grbScientifica.Visible = false;
                grbGeometria.Visible = true;

            }
            else
            {
                grbBase.Visible = true;
                grbGeometria.Visible = false;
                grbScientifica.Visible = true;
            }
        }
        private void rdbBaseScieGeo_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbBaseScieGeo.Checked)
            {
                MessageBox.Show("Puoi visualizzare tutte le modalita' ma puoi usarne solo una", "Informazione", MessageBoxButtons.OK, MessageBoxIcon.Information);
                grbBase.Visible = true;
                grbScientifica.Visible = true;
                grbGeometria.Visible = true;
            }
        }

        //checked operazioni alternative
        private void chkRadiceQuadrata_CheckedChanged_1(object sender, EventArgs e)
        {
            if (VerificaChecked() <= 1)
            {
                lblValoreB.Visible = false;
                textBox3.Visible = false;
                lblValoreA.Text = "Inserisci valore X";
                radiceQuadrata = true;
            }
        }
        private void chkPotenze_CheckedChanged(object sender, EventArgs e)
        {
            if (VerificaChecked() <= 1)
            {
                textBox.Visible = true;
                lblValoreA.Visible = true;
                lblValoreA.Text = "Inserire la BASE";
                lblValoreB.Visible = true;
                textBox3.Visible = true;
                lblValoreB.Text = "Inserire l'ESPONENTE";

                potenza = true;
            }
        }
        private void chkFattoriale_CheckedChanged(object sender, EventArgs e)
        {
            if (VerificaChecked() <= 1)
            {
                lblValoreB.Visible = false;
                textBox3.Visible = false;
                lblValoreA.Text = "Inserisci valore X";
                fattoriale = true;
            }
        }
        private void chkSeno_CheckedChanged(object sender, EventArgs e)
        {
            if (VerificaChecked() <= 1)
            {
                lblValoreB.Visible = false;
                textBox3.Visible = false;
                lblValoreA.Text = "Inserisci l'angolo X";
                seno = true;
            }
        }
        private void chkCoseno_CheckedChanged(object sender, EventArgs e)
        {
            if (VerificaChecked() <= 1)
            {
                lblValoreB.Visible = false;
                textBox3.Visible = false;
                lblValoreA.Text = "Inserisci l'angolo X";
                coseno = true;
            }
        }
        private void chkTangente_CheckedChanged(object sender, EventArgs e)
        {
            if (VerificaChecked() <= 1)
            {
                lblValoreB.Visible = false;
                textBox3.Visible = false;
                lblValoreA.Text = "Inserisci l'angolo X";
                tangente = true;
            }
        }

        //combobox scelta della figura
        private void cmbSceltaFigura_SelectedIndexChanged(object sender, EventArgs e)
        {          
            //modi alternativi per la scelta della figura
            //string testo = cmbSceltaFigura.SelectedItem.ToString();
            //string item = cmbSceltaFigura.Items[1].ToString();
            //il codice scritto qua dentro l'ho spostato direttamente sui rdb area e perimetro come indicato dalla prof
        }
        private void rdbArea_CheckedChanged(object sender, EventArgs e)
        {
            rettangolo = false;
            quadrato = false;
            rombo = false;
            parallelogramma = false;
            cerchio = false;

            string scelta = cmbSceltaFigura.Text;

            switch (scelta)
            {
                case "Rettangolo":
                    rettangolo = true;
                    textBox.Visible = true;
                    lblValoreB.Visible = true;
                    textBox3.Visible = true;
                    lblValoreA.Text = "Base";
                    lblValoreB.Text = "Altezza";
                    break;

                case "Quadrato":
                    quadrato = true;
                    lblValoreA.Text = "Lato";
                    textBox3.Visible = false;
                    lblValoreB.Visible = false;
                    break;

                case "Parallelogramma": //se clicchi area serve base e altezza, perimetro lato obliquo e base
                    parallelogramma = true;

                    if (rdbArea.Checked)
                    {
                        lblValoreA.Text = "Base";
                        textBox.Visible = true;
                        lblValoreB.Visible = true;
                        lblValoreB.Text = "Lato obliquo";
                        textBox3.Visible = true;
                    }
                    else if (rdbPerimetro.Checked)
                    {
                        lblValoreA.Text = "Base";
                        textBox.Visible = true;
                        lblValoreB.Visible = true;
                        lblValoreB.Text = "Altezza";
                        textBox3.Visible = true;
                    }
                    break;

                case "Rombo": //se clicchi area serve diagonale maggiore e minore, perimetro (l * 4) ha bisogno del lato
                    rombo = true;

                    if (rdbArea.Checked)
                    {
                        lblValoreA.Text = "Diagonale Maggiore";
                        textBox.Visible = true;
                        lblValoreB.Visible = true;
                        lblValoreB.Text = "Diagonale Minore";
                        textBox3.Visible = true;
                    }
                    if (rdbPerimetro.Checked)
                    {
                        lblValoreA.Text = "Lato";
                        textBox.Visible = true;
                        lblValoreB.Visible = false;
                        textBox3.Visible = false;
                    }
                    break;

                case "Cerchio":
                    cerchio = true;
                    lblValoreA.Text = "Diametro";
                    textBox3.Visible = false;
                    lblValoreB.Visible = false;
                    break;

                default:
                    break;
            }
        }
        private void rdbPerimetro_CheckedChanged(object sender, EventArgs e)
        {
            rettangolo = false;
            quadrato = false;
            rombo = false;
            parallelogramma = false;
            cerchio = false;

            string scelta = cmbSceltaFigura.Text;

            switch (scelta)
            {
                case "Rettangolo":
                    rettangolo = true;
                    textBox.Visible = true;
                    lblValoreB.Visible = true;
                    textBox3.Visible = true;
                    lblValoreA.Text = "Base";
                    lblValoreB.Text = "Altezza";
                    break;

                case "Quadrato":
                    quadrato = true;
                    lblValoreA.Text = "Lato";
                    textBox3.Visible = false;
                    lblValoreB.Visible = false;
                    break;

                case "Parallelogramma": //se clicchi area serve base e altezza, perimetro lato obliquo e base
                    parallelogramma = true;

                    if (rdbArea.Checked)
                    {
                        lblValoreA.Text = "Base";
                        textBox.Visible = true;
                        lblValoreB.Visible = true;
                        lblValoreB.Text = "Lato obliquo";
                        textBox3.Visible = true;
                    }
                    else if (rdbPerimetro.Checked)
                    {
                        lblValoreA.Text = "Base";
                        textBox.Visible = true;
                        lblValoreB.Visible = true;
                        lblValoreB.Text = "Altezza";
                        textBox3.Visible = true;
                    }
                    break;

                case "Rombo": //se clicchi area serve diagonale maggiore e minore, perimetro (l * 4) ha bisogno del lato
                    rombo = true;

                    if (rdbArea.Checked)
                    {
                        lblValoreA.Text = "Diagonale Maggiore";
                        textBox.Visible = true;
                        lblValoreB.Visible = true;
                        lblValoreB.Text = "Diagonale Minore";
                        textBox3.Visible = true;
                    }
                    if (rdbPerimetro.Checked)
                    {
                        lblValoreA.Text = "Lato";
                        textBox.Visible = true;
                        lblValoreB.Visible = false;
                        textBox3.Visible = false;
                    }
                    break;

                case "Cerchio":
                    cerchio = true;
                    lblValoreA.Text = "Diametro";
                    textBox3.Visible = false;
                    lblValoreB.Visible = false;
                    break;

                default:
                    break;
            }
        }

        //bottoni geometria solida
        private void btnGeometriaSolita_Click(object sender, EventArgs e)
        {
            FrmGeometriaSolida form = new FrmGeometriaSolida();

            form.ShowDialog();
        }
        private void btnGeometriaSolidaComp_Click(object sender, EventArgs e)
        {
            FrmGeometriaSolidaC form = new FrmGeometriaSolidaC();

            form.ShowDialog();
        }
        private void btnGeometriaPiana_Click(object sender, EventArgs e)
        {
            FormFigure3 form = new FormFigure3();

            form.ShowDialog();
        }

        //gestione menu strip
        private void mnuCalcolatrice_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void menuGestioneDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDate form = new frmDate();

            form.ShowDialog();
        }
        private void gestioneStringheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmStringhe form = new frmStringhe();  

            form.ShowDialog();
        }
        private void gestioneGestioneFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFiles form = new frmFiles();

            form.ShowDialog();
        }
    }
}
